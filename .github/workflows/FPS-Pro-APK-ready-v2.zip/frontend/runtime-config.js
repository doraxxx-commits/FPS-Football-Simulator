// FPS-Pro backend configuration
window.FPS_API_URL = 'https://fps-pro.onrender.com';
