window.addEventListener('error', e => { 
  console.error(e.error || e.message); 
});

let S = null;
let league = 'Ekstraklasa';
let toastTimer = null;

const $ = id => document.getElementById(id);

const esc = x => String(x ?? '').replace(/[&<>"']/g, m => ({ 
  '&': '&amp;', 
  '<': '&lt;', 
  '>': '&gt;', 
  '"': '&quot;', 
  "'": '&#39;' 
}[m]));

function toast(t) {
  const el = $('toast');
  if (!el) return;
  if (toastTimer) clearTimeout(toastTimer);
  
  el.textContent = t;
  el.classList.remove('show');
  void el.offsetWidth;
  el.classList.add('show');
  toastTimer = setTimeout(() => el.classList.remove('show'), 2400);
}

function vib(pattern = 18) {
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function' && !/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
      navigator.vibrate(pattern);
    }
  } catch (e) {}
}

function audio(type) {
  try {
    const C = window.AudioContext || window.webkitAudioContext;
    if (!C) return;
    const c = new C();
    if (c.state === 'suspended') c.resume();

    const o = c.createOscillator();
    const g = c.createGain();
    o.connect(g);
    g.connect(c.destination);
    const now = c.currentTime;

    if (type === 'click') {
      o.type = 'sine';
      o.frequency.setValueAtTime(550, now);
      o.frequency.exponentialRampToValueAtTime(180, now + 0.05);
      g.gain.setValueAtTime(0.06, now);
      g.gain.linearRampToValueAtTime(0.001, now + 0.05);
      o.start(now);
      o.stop(now + 0.06);
    } else if (type === 'perk') {
      o.type = 'triangle';
      o.frequency.setValueAtTime(400, now);
      o.frequency.exponentialRampToValueAtTime(850, now + 0.15);
      g.gain.setValueAtTime(0.1, now);
      g.gain.linearRampToValueAtTime(0.001, now + 0.18);
      o.start(now);
      o.stop(now + 0.19);
    } else if (type === 'goal' || type === 'win') {
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(220, now);
      o.frequency.exponentialRampToValueAtTime(660, now + 0.3);
      g.gain.setValueAtTime(0.12, now);
      g.gain.linearRampToValueAtTime(0.001, now + 0.35);
      o.start(now);
      o.stop(now + 0.36);
    }
  } catch (e) {}
}

document.addEventListener('click', (e) => {
  if (e.target.tagName === 'BUTTON' || e.target.closest('button')) {
    audio('click');
  }
});

document.addEventListener('pointerdown', (e) => {
  const btn = e.target.closest('button');
  if (!btn || btn.closest('#nav')) return;
  const rect = btn.getBoundingClientRect();
  const ripple = document.createElement('span');
  const size = Math.max(rect.width, rect.height) * 1.4;
  ripple.className = 'ripple';
  ripple.style.width = ripple.style.height = `${size}px`;
  ripple.style.left = `${(e.clientX ?? rect.left + rect.width / 2) - rect.left - size / 2}px`;
  ripple.style.top = `${(e.clientY ?? rect.top + rect.height / 2) - rect.top - size / 2}px`;
  btn.appendChild(ripple);
  ripple.addEventListener('animationend', () => ripple.remove(), { once: true });
});

const NAV_ORDER = ['home', 'career', 'club', 'world', 'cups', 'national', 'profile'];
let currentScreenName = 'home';

function openGame() {
  const onboarding = $('onboarding');
  const game = $('game');

  if (onboarding) {
    onboarding.classList.add('hidden');
    onboarding.classList.remove('active');
  }
  if (game) {
    game.classList.remove('hidden');
    game.classList.add('active');
  }
  currentScreenName = 'home';
  renderAll();
}

function showModal(html) {
  const m = $('modal');
  const mc = $('modalContent');
  if (mc) mc.innerHTML = html;
  if (m) {
    m.classList.remove('hidden', 'closing');
  }
}

window.closeModal = function() {
  const m = $('modal');
  if (!m || m.classList.contains('hidden')) return;
  m.classList.add('closing');
  m.addEventListener('animationend', function handler() {
    m.classList.add('hidden');
    m.classList.remove('closing');
    m.removeEventListener('animationend', handler);
  }, { once: true });
};

function nav(name) {
  if (name === currentScreenName) return;
  const newEl = $(`screen-${name}`);
  if (!newEl) return;
  const oldEl = document.querySelector('.screen.active');

  const oldIndex = NAV_ORDER.indexOf(currentScreenName);
  const newIndex = NAV_ORDER.indexOf(name);
  const dir = newIndex > oldIndex ? 'next' : 'prev';

  document.querySelectorAll('#nav button').forEach(b => {
    b.classList.toggle('active', b.dataset.screen === name);
  });

  renderScreen(name);

  if (oldEl && oldEl !== newEl) {
    oldEl.classList.remove('active');
  }

  newEl.classList.remove('enter-next', 'enter-prev');
  newEl.classList.add('active', dir === 'next' ? 'enter-next' : 'enter-prev');
  newEl.addEventListener('animationend', function handler() {
    newEl.classList.remove('enter-next', 'enter-prev');
    newEl.removeEventListener('animationend', handler);
  }, { once: true });

  currentScreenName = name;
  vib(10);
}

window.startCareer = async function(event) {
  if (event) event.preventDefault();

  const payload = {
    firstName: $('firstName')?.value.trim() || 'Mateusz',
    lastName: $('lastName')?.value.trim() || 'Kowalski',
    position: $('position')?.value || 'ST',
    age: Number($('age')?.value || 18)
  };

  if (!payload.firstName || !payload.lastName) {
    return toast('Wpisz imię i nazwisko');
  }
  
  try {
    const response = await window.api('/career/create', { 
      method: 'POST', 
      body: JSON.stringify(payload) 
    });
    S = response.state || response;
    
    if (S.offers && S.offers.length > 0) {
      openOffers(S.offers);
    } else {
      openGame();
    }
  } catch (err) {
    toast(err.message || 'Błąd tworzenia kariery');
  }
};

function openOffers(offersList) {
  const offers = offersList || (S ? S.offers : []);
  if (!offers || offers.length === 0) {
    openGame();
    return;
  }

  showModal(`
    <div class="eyebrow">PIERWSZY KONTRAKT</div>
    <h2 style="color:#fff; margin-bottom:8px;">Wybierz swój pierwszy klub</h2>
    <p class="muted" style="margin-bottom:16px;">Kliknij ofertę, aby przejść do negocjacji warunków.</p>
    <div style="max-height: 50vh; overflow-y: auto; padding-right: 4px;">
      ${offers.map(o => {
        const clubIdValue = o.clubId !== undefined ? o.clubId : (o.id !== undefined ? o.id : o.club);
        return `
          <button class="ghost offer-btn" data-clubid="${clubIdValue}" data-clubname="${esc(o.club)}" data-wage="${o.wage || 3000}" style="width:100%; margin-bottom:8px; text-align:left; border-radius:12px;">
            <b>${esc(o.club)}</b><br>
            <span style="font-size:0.75rem; color:var(--text-muted);">
              ${o.league ? esc(o.league) + ' • ' : ''} Oferowana pensja: ${o.wage ? Number(o.wage).toLocaleString() : 0} PLN/tydz.
            </span>
          </button>
        `;
      }).join('')}
    </div>
  `);

  document.querySelectorAll('.offer-btn').forEach(b => {
    b.onclick = () => {
      const selectedClub = b.dataset.clubid;
      const parsedId = !isNaN(selectedClub) ? Number(selectedClub) : selectedClub;
      const clubName = b.dataset.clubname;
      const baseWage = Number(b.dataset.wage);
      
      openNegotiationModal(parsedId, clubName, baseWage);
    };
  });
}

window.openNegotiationModal = function(clubId, clubName, baseWage, initialPatience = 100, alertMsg = '') {
  showModal(`
    <div class="eyebrow">NEGOCJACJE KONTRAKTU</div>
    <h2 style="color:#fff; margin-bottom:4px;">${esc(clubName)}</h2>
    <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:12px;">
      Cierpliwość zarządu: <b style="color:${initialPatience > 50 ? 'var(--accent-green)' : '#ef4444'};">${initialPatience}%</b>
    </p>

    ${alertMsg ? `<div style="background:rgba(239, 68, 68, 0.15); border:1px solid #ef4444; color:#fff; padding:8px 12px; border-radius:8px; font-size:0.75rem; margin-bottom:12px;">${alertMsg}</div>` : ''}

    <div style="margin-bottom:10px;">
      <label style="font-size:0.75rem; color:var(--text-muted);">ŻĄDANA PENSJA TYGODNIOWA (PLN):</label>
      <input type="number" id="neg-wage" value="${baseWage}" style="width:100%; padding:10px; margin-top:4px; background:rgba(0,0,0,0.3); border:1px solid var(--border-color); color:#fff; border-radius:8px; font-weight:bold;">
    </div>

    <button class="action primaryAction" style="width:100%; padding:12px; margin-top:4px;" onclick="window.submitContractOffer('${clubId}', '${esc(clubName)}', ${initialPatience})">
      📑 PRZEDSTAW WARUNKI
    </button>
    <button class="action" style="width:100%; margin-top:6px;" onclick="closeModal()">ANULUJ</button>
  `);
};

window.submitContractOffer = async function(clubId, clubName, patience) {
  const wage = Number($('neg-wage')?.value || 0);

  try {
    const res = await window.api('/contract/negotiate', { 
      method: 'POST', 
      body: JSON.stringify({ clubId, wage, patience }) 
    });

    closeModal();
    openGame();
    audio('win');
    vib([30, 50, 30]);
    toast(res.message || 'Podpisano kontrakt!');
    updateStateAndUI(res.state);
  } catch (e) {
    toast(e.message);
  }
};

async function saveGame() {
  try {
    const snap = await window.api('/save');
    localStorage.setItem('fps_slot1', JSON.stringify(snap));
    toast('Zapisano karierę');
    vib(20);
  } catch (e) { 
    toast(e.message); 
  }
}

function updateStateAndUI(newState) {
  S = newState;
  renderAll();
}

function renderAll() {
  if (!S) return;
  
  if (S.calendar && S.club) {
    const sLabel = $('seasonLabel');
    const cLabel = $('clubLabel');
    if (sLabel) sLabel.textContent = `${S.calendar.season} • KOLEJKA ${S.calendar.matchday}/${S.calendar.totalMatchdays || 30}`;
    if (cLabel) cLabel.textContent = S.club.name || '—';
  }
  
  const activeScreen = document.querySelector('.screen.active');
  if (activeScreen) {
    renderScreen(activeScreen.id.replace('screen-', ''));
  }
  updateCustomUI(S);
}

window.renderAll = renderAll;

function renderScreen(name) {
  if (!S) return;
  ({
    home: renderHome, 
    career: renderCareer, 
    club: renderClub,
    world: renderWorld, 
    cups: renderCups, 
    national: renderNational, 
    profile: renderProfile
  }[name] || renderHome)();
}

function initials(name) {
  return String(name || '?').split(' ').filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

function renderHome() {
  const f = S.fixture;
  const trust = S.relationships?.managerTrust ?? 50;
  const condition = S.player?.condition ?? 100;

  $('screen-home').innerHTML = `
    <div class="hero-card">
      <div class="eyebrow">${esc(S.club?.league || 'Liga')} • ${S.club?.position || 1}. MIEJSCE</div>
      <div class="matchline">
        <div>
          <div class="name">${esc(S.player?.name || 'Gracz')}</div>
          <p>${S.player?.age || 18} lat • ${esc(S.player?.position || 'ST')} • #${S.player?.number || 10}</p>
        </div>
        <div class="ovr">${S.player?.ovr || 60}<small>OVR</small></div>
      </div>
      <div class="stat-row">
        <div class="labels"><span class="lbl">Dyspozycja</span><span class="val">${condition}%</span></div>
        <div class="track"><div class="home" style="width:${condition}%"></div></div>
      </div>
    </div>

    <div class="hero-card match-card">
      <div class="eyebrow live"><span class="dot"></span>NASTĘPNY MECZ</div>
      <div class="badge-row">
        <div class="crest">${initials(f?.home)}</div>
        <div class="score-block">
          <div class="score">VS</div>
          <div class="sub">${esc(S.calendar?.season || '')}</div>
        </div>
        <div class="crest">${initials(f?.away)}</div>
      </div>
      <div class="team-names"><b>${esc(f?.home || '—')}</b><span>KOLEJKA ${S.calendar?.matchday || 1}</span><b>${esc(f?.away || '—')}</b></div>
      <button class="primary" style="margin-top:16px;" onclick="window.simulate()">▶ ROZEGRAJ MECZ</button>
      <button class="ghost" style="margin-top:8px;" onclick="window.trainingModal()">🏋️ TRENING</button>
    </div>

    <div class="hero-card">
      <div class="eyebrow">STATUS KLUBOWY</div>
      <div class="statgrid">
        <div class="mini">
          <span>Portfel</span>
          <b>${(S.finances?.balance || 0).toLocaleString()} PLN</b>
        </div>
        <div class="mini">
          <span>Zaufanie trenera</span>
          <b>${trust}/100</b>
          <div class="meter"><span style="width:${trust}%"></span></div>
        </div>
      </div>
    </div>
  `;
}

window.simulate = async function() {
  try {
    const d = await window.api('/match/simulate', { method: 'POST' });
    S = d.state || d;
    audio('goal');
    vib([30, 50, 30]);
    toast(`Mecz rozegrany!`);
    renderAll();
  } catch (e) { 
    toast(e.message); 
  }
};

window.trainingModal = async function() {
  try {
    S = await window.api('/training', { method: 'POST' });
    toast('Trening zaliczony! OVR +1');
    vib(18);
    renderAll();
  } catch (e) {
    toast(e.message);
  }
};

function renderCareer() {
  const matches = S.stats?.matches || 0;
  const goals = S.stats?.goals || 0;
  const assists = S.stats?.assists || 0;
  const minutes = S.stats?.minutes || 0;
  $('screen-career').innerHTML = `
    <div class="topbar"><h2>Twoja kariera</h2></div>
    <div class="hero-card">
      <div class="eyebrow">SEZON ${esc(S.calendar?.season || '')}</div>
      <div class="statgrid">
        <div class="mini"><span>Mecze</span><b>${matches}</b></div>
        <div class="mini"><span>Gole</span><b>${goals}</b></div>
        <div class="mini"><span>Asysty</span><b>${assists}</b></div>
        <div class="mini"><span>Minuty</span><b>${minutes}'</b></div>
      </div>
    </div>
    <div class="hero-card">
      <div class="eyebrow">PUNKTY UMIEJĘTNOŚCI</div>
      <p>Do wykorzystania: <strong>${S.skillPoints || 0}</strong></p>
    </div>
  `;
}

async function renderClub() {
  const cName = S.club?.name || 'Klub';
  const chem = S.teamChemistry ?? 70;
  $('screen-club').innerHTML = `
    <div class="hero-card">
      <div class="eyebrow">${esc(S.club?.league || 'Liga')}</div>
      <div class="badge-row">
        <div class="crest">${initials(cName)}</div>
        <div class="score-block">
          <div class="score">#${S.club?.position || 1}</div>
          <div class="sub">Miejsce w lidze</div>
        </div>
      </div>
      <h2 style="text-align:center; margin-top:6px;">${esc(cName)}</h2>
      <div class="stat-row">
        <div class="labels"><span class="lbl">Chemia zespołu</span><span class="val">${chem}%</span></div>
        <div class="track"><div class="home" style="width:${chem}%"></div></div>
      </div>
    </div>
  `;
}

async function renderWorld() {
  const myPts = (S.calendar?.matchday || 1) * 3;
  $('screen-world').innerHTML = `
    <div class="topbar"><h2>Tabela ligowa</h2></div>
    <div class="hero-card">
      <div class="eyebrow">${esc(league)}</div>
      <div class="stat-row"><div class="labels"><span class="lbl">1. ${esc(S.club?.name || '—')}</span><span class="val">${myPts} pkt</span></div>
        <div class="track"><div class="home" style="width:100%"></div></div></div>
      <div class="stat-row"><div class="labels"><span class="lbl">2. Lech Poznań</span><span class="val">0 pkt</span></div>
        <div class="track"><div class="away" style="width:8%"></div></div></div>
    </div>
  `;
}

function renderCups() {
  $('screen-cups').innerHTML = `
    <div class="topbar"><h2>Gablota trofeów</h2></div>
    <div class="hero-card"><p class="muted">Brak nowych trofeów — zdobądź pierwszy puchar w tym sezonie.</p></div>
  `;
}

function renderNational() {
  $('screen-national').innerHTML = `
    <div class="topbar"><h2>Reprezentacja</h2></div>
    <div class="hero-card"><p class="muted">Powołania wkrótce — utrzymuj wysoką formę klubową.</p></div>
  `;
}

function renderProfile() {
  $('screen-profile').innerHTML = `
    <div class="hero-card">
      <div class="badge-row"><div class="crest">${initials(S.player?.name)}</div></div>
      <h2 style="text-align:center;">${esc(S.player?.name)}</h2>
      <p style="text-align:center;">${esc(S.club?.name || '')}</p>
    </div>
    <div class="hero-card">
      <button class="primary" onclick="saveGame()">💾 ZAPISZ GRĘ LOKALNIE</button>
    </div>
  `;
}

function updateCustomUI(state) {}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('#nav button').forEach(b => {
    b.onclick = () => nav(b.dataset.screen);
  });
  
  $('loadSlot')?.addEventListener('click', async e => {
    e.preventDefault();
    const raw = localStorage.getItem('fps_offline_db');
    if (!raw) return toast('Brak zapisu');
    S = JSON.parse(raw);
    openGame();
    toast('Wczytano zapis');
  });

  $('clearSaves')?.addEventListener('click', () => { 
    localStorage.removeItem('fps_offline_db'); 
    toast('Zapis usunięty'); 
  });

  (async () => {
    try {
      S = await window.api('/state');
      if (S && S.created && S.club?.name) {
        openGame();
      }
    } catch (e) {}
  })();
});
