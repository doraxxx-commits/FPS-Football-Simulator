window.addEventListener('error', e => { 
  console.error(e.error || e.message); 
});

let S = null;
let league = 'Ekstraklasa';
let toastTimer = null;

const $ = id => document.getElementById(id);

const esc = x => String(x ?? '').replace(/[&<>"']/g, m => ({ 
  '&': '&amp;', 
  '<': '&lt;', 
  '>': '&gt;', 
  '"': '&quot;', 
  "'": '&#39;' 
}[m]));

function toast(t) {
  const el = $('toast');
  if (!el) return;
  if (toastTimer) clearTimeout(toastTimer);
  
  el.textContent = t;
  el.classList.remove('show');
  void el.offsetWidth;
  el.classList.add('show');
  toastTimer = setTimeout(() => el.classList.remove('show'), 2400);
}

function vib(pattern = 18) {
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function' && !/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
      navigator.vibrate(pattern);
    }
  } catch (e) {}
}

function audio(type) {
  try {
    const C = window.AudioContext || window.webkitAudioContext;
    if (!C) return;
    const c = new C();
    if (c.state === 'suspended') c.resume();

    const o = c.createOscillator();
    const g = c.createGain();
    o.connect(g);
    g.connect(c.destination);
    const now = c.currentTime;

    if (type === 'click') {
      o.type = 'sine';
      o.frequency.setValueAtTime(550, now);
      o.frequency.exponentialRampToValueAtTime(180, now + 0.05);
      g.gain.setValueAtTime(0.06, now);
      g.gain.linearRampToValueAtTime(0.001, now + 0.05);
      o.start(now);
      o.stop(now + 0.06);
    } else if (type === 'perk') {
      o.type = 'triangle';
      o.frequency.setValueAtTime(400, now);
      o.frequency.exponentialRampToValueAtTime(850, now + 0.15);
      g.gain.setValueAtTime(0.1, now);
      g.gain.linearRampToValueAtTime(0.001, now + 0.18);
      o.start(now);
      o.stop(now + 0.19);
    } else if (type === 'goal' || type === 'win') {
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(220, now);
      o.frequency.exponentialRampToValueAtTime(660, now + 0.3);
      g.gain.setValueAtTime(0.12, now);
      g.gain.linearRampToValueAtTime(0.001, now + 0.35);
      o.start(now);
      o.stop(now + 0.36);
    }
  } catch (e) {}
}

document.addEventListener('click', (e) => {
  if (e.target.tagName === 'BUTTON' || e.target.closest('button')) {
    audio('click');
  }
});

function openGame() {
  const onboarding = $('onboarding');
  const game = $('game');
  
  if (onboarding) { 
    onboarding.classList.add('hidden'); 
    onboarding.classList.remove('active'); 
  }
  if (game) { 
    game.classList.remove('hidden'); 
    game.classList.add('active'); 
  }
  renderAll();
}

function showModal(html) {
  const m = $('modal');
  const mc = $('modalContent');
  if (mc) mc.innerHTML = html;
  if (m) m.classList.remove('hidden');
}

window.closeModal = function() {
  $('modal')?.classList.add('hidden');
};

function nav(name) {
  document.querySelectorAll('.screen').forEach(x => x.classList.remove('active'));
  $(`screen-${name}`)?.classList.add('active');
  
  document.querySelectorAll('#nav button').forEach(b => {
    b.classList.toggle('active', b.dataset.screen === name);
  });
  
  renderScreen(name);
  vib(10);
}

window.startCareer = async function(event) {
  if (event) event.preventDefault();

  const payload = {
    firstName: $('firstName')?.value.trim() || 'Mateusz',
    lastName: $('lastName')?.value.trim() || 'Kowalski',
    position: $('position')?.value || 'ST',
    age: Number($('age')?.value || 18)
  };

  if (!payload.firstName || !payload.lastName) {
    return toast('Wpisz imię i nazwisko');
  }
  
  try {
    const response = await window.api('/career/create', { 
      method: 'POST', 
      body: JSON.stringify(payload) 
    });
    S = response.state || response;
    
    if (S.offers && S.offers.length > 0) {
      openOffers(S.offers);
    } else {
      openGame();
    }
  } catch (err) {
    toast(err.message || 'Błąd tworzenia kariery');
  }
};

function openOffers(offersList) {
  const offers = offersList || (S ? S.offers : []);
  if (!offers || offers.length === 0) {
    openGame();
    return;
  }

  showModal(`
    <div class="eyebrow">PIERWSZY KONTRAKT</div>
    <h2 style="color:#fff; margin-bottom:8px;">Wybierz swój pierwszy klub</h2>
    <p class="muted" style="margin-bottom:16px;">Kliknij ofertę, aby przejść do negocjacji warunków.</p>
    <div style="max-height: 50vh; overflow-y: auto; padding-right: 4px;">
      ${offers.map(o => {
        const clubIdValue = o.clubId !== undefined ? o.clubId : (o.id !== undefined ? o.id : o.club);
        return `
          <button class="ghost offer-btn" data-clubid="${clubIdValue}" data-clubname="${esc(o.club)}" data-wage="${o.wage || 3000}" style="width:100%; margin-bottom:8px; text-align:left; border-radius:12px;">
            <b>${esc(o.club)}</b><br>
            <span style="font-size:0.75rem; color:var(--text-muted);">
              ${o.league ? esc(o.league) + ' • ' : ''} Oferowana pensja: ${o.wage ? Number(o.wage).toLocaleString() : 0} PLN/tydz.
            </span>
          </button>
        `;
      }).join('')}
    </div>
  `);

  document.querySelectorAll('.offer-btn').forEach(b => {
    b.onclick = () => {
      const selectedClub = b.dataset.clubid;
      const parsedId = !isNaN(selectedClub) ? Number(selectedClub) : selectedClub;
      const clubName = b.dataset.clubname;
      const baseWage = Number(b.dataset.wage);
      
      openNegotiationModal(parsedId, clubName, baseWage);
    };
  });
}

window.openNegotiationModal = function(clubId, clubName, baseWage, initialPatience = 100, alertMsg = '') {
  showModal(`
    <div class="eyebrow">NEGOCJACJE KONTRAKTU</div>
    <h2 style="color:#fff; margin-bottom:4px;">${esc(clubName)}</h2>
    <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:12px;">
      Cierpliwość zarządu: <b style="color:${initialPatience > 50 ? 'var(--accent-green)' : '#ef4444'};">${initialPatience}%</b>
    </p>

    ${alertMsg ? `<div style="background:rgba(239, 68, 68, 0.15); border:1px solid #ef4444; color:#fff; padding:8px 12px; border-radius:8px; font-size:0.75rem; margin-bottom:12px;">${alertMsg}</div>` : ''}

    <div style="margin-bottom:10px;">
      <label style="font-size:0.75rem; color:var(--text-muted);">ŻĄDANA PENSJA TYGODNIOWA (PLN):</label>
      <input type="number" id="neg-wage" value="${baseWage}" style="width:100%; padding:10px; margin-top:4px; background:rgba(0,0,0,0.3); border:1px solid var(--border-color); color:#fff; border-radius:8px; font-weight:bold;">
    </div>

    <button class="action primaryAction" style="width:100%; padding:12px; margin-top:4px;" onclick="window.submitContractOffer('${clubId}', '${esc(clubName)}', ${initialPatience})">
      📑 PRZEDSTAW WARUNKI
    </button>
    <button class="action" style="width:100%; margin-top:6px;" onclick="closeModal()">ANULUJ</button>
  `);
};

window.submitContractOffer = async function(clubId, clubName, patience) {
  const wage = Number($('neg-wage')?.value || 0);

  try {
    const res = await window.api('/contract/negotiate', { 
      method: 'POST', 
      body: JSON.stringify({ clubId, wage, patience }) 
    });

    closeModal();
    openGame();
    audio('win');
    vib([30, 50, 30]);
    toast(res.message || 'Podpisano kontrakt!');
    updateStateAndUI(res.state);
  } catch (e) {
    toast(e.message);
  }
};

async function saveGame() {
  try {
    const snap = await window.api('/save');
    localStorage.setItem('fps_slot1', JSON.stringify(snap));
    toast('Zapisano karierę');
    vib(20);
  } catch (e) { 
    toast(e.message); 
  }
}

function updateStateAndUI(newState) {
  S = newState;
  renderAll();
}

function renderAll() {
  if (!S) return;
  
  if (S.calendar && S.club) {
    const sLabel = $('seasonLabel');
    const cLabel = $('clubLabel');
    if (sLabel) sLabel.textContent = `${S.calendar.season} • KOLEJKA ${S.calendar.matchday}/${S.calendar.totalMatchdays || 30}`;
    if (cLabel) cLabel.textContent = S.club.name || '—';
  }
  
  const activeScreen = document.querySelector('.screen.active');
  if (activeScreen) {
    renderScreen(activeScreen.id.replace('screen-', ''));
  }
  updateCustomUI(S);
}

window.renderAll = renderAll;

function renderScreen(name) {
  if (!S) return;
  ({
    home: renderHome, 
    career: renderCareer, 
    club: renderClub,
    world: renderWorld, 
    cups: renderCups, 
    national: renderNational, 
    profile: renderProfile
  }[name] || renderHome)();
}

function renderHome() {
  const f = S.fixture;
  $('screen-home').innerHTML = `
    <div class="hero-card">
      <div class="eyebrow">${esc(S.club?.league || 'Liga')} • ${S.club?.position || 1}. MIEJSCE</div>
      <h2>${esc(S.player?.name || 'Gracz')} <small>#${S.player?.number || 10}</small></h2>
      <p>${S.player?.age || 18} lat • ${S.player?.position || 'ST'} • OVR: <strong>${S.player?.ovr || 60}</strong></p>
    </div>

    <div class="hero-card">
      <div class="eyebrow">NASTĘPNY MECZ</div>
      <div style="margin: 12px 0; font-weight:bold;">${esc(f?.home || '—')} VS ${esc(f?.away || '—')}</div>
      <button class="primary" onclick="window.simulate()">▶ ROZEGRAJ MECZ</button>
      <button class="ghost" style="margin-top:8px;" onclick="window.trainingModal()">🏋️ TRENING</button>
    </div>

    <div class="hero-card">
      <div>💰 Portfel: <strong>${S.finances?.balance || 0}</strong> PLN</div>
      <div>👔 Zaufanie Trenera: <strong>${S.relationships?.managerTrust || 50}</strong>/100</div>
    </div>
  `;
}

window.simulate = async function() {
  try {
    const d = await window.api('/match/simulate', { method: 'POST' });
    S = d.state || d;
    audio('goal');
    vib([30, 50, 30]);
    toast(`Mecz rozegrany!`);
    renderAll();
  } catch (e) { 
    toast(e.message); 
  }
};

window.trainingModal = async function() {
  try {
    S = await window.api('/training', { method: 'POST' });
    toast('Trening zaliczony! OVR +1');
    vib(18);
    renderAll();
  } catch (e) {
    toast(e.message);
  }
};

function renderCareer() {
  $('screen-career').innerHTML = `
    <div class="hero-card">
      <h2>Twoje statystyki</h2>
      <p>Mecze: ${S.stats?.matches || 0}</p>
      <p>Gole: ${S.stats?.goals || 0}</p>
    </div>
  `;
}

async function renderClub() {
  $('screen-club').innerHTML = `
    <div class="hero-card">
      <h2>${esc(S.club?.name || 'Klub')}</h2>
      <p>Liczba zawodników w kadrze: 11</p>
    </div>
  `;
}

async function renderWorld() {
  $('screen-world').innerHTML = `
    <div class="hero-card">
      <h2>Tabela Ligowa</h2>
      <p>1. ${esc(S.club?.name)} - Pkt: ${S.calendar?.matchday * 3 || 0}</p>
      <p>2. Lech Poznań - Pkt: 0</p>
    </div>
  `;
}

function renderCups() {
  $('screen-cups').innerHTML = `<div class="hero-card"><h2>Gabliota Trofeów</h2><p>Brak nowych trofeów.</p></div>`;
}

function renderNational() {
  $('screen-national').innerHTML = `<div class="hero-card"><h2>Reprezentacja</h2><p>Powołania wkrótce.</p></div>`;
}

function renderProfile() {
  $('screen-profile').innerHTML = `
    <div class="hero-card">
      <h2>${esc(S.player?.name)}</h2>
      <button class="primary" onclick="saveGame()">💾 ZAPISZ GRĘ LOKALNIE</button>
    </div>
  `;
}

function updateCustomUI(state) {}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('#nav button').forEach(b => {
    b.onclick = () => nav(b.dataset.screen);
  });
  
  $('loadSlot')?.addEventListener('click', async e => {
    e.preventDefault();
    const raw = localStorage.getItem('fps_offline_db');
    if (!raw) return toast('Brak zapisu');
    S = JSON.parse(raw);
    openGame();
    toast('Wczytano zapis');
  });

  $('clearSaves')?.addEventListener('click', () => { 
    localStorage.removeItem('fps_offline_db'); 
    toast('Zapis usunięty'); 
  });

  (async () => {
    try {
      S = await window.api('/state');
      if (S && S.created && S.club?.name) {
        openGame();
      }
    } catch (e) {}
  })();
});
