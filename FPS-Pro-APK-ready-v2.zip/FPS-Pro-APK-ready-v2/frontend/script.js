let gameState = null;

// 1. Inicjalizacja kariery
window.startCareer = async function(event) {
    if (event) event.preventDefault();

    const firstName = document.getElementById('firstName')?.value || 'Mateusz';
    const lastName = document.getElementById('lastName')?.value || 'Kowalski';
    const position = document.getElementById('position')?.value || 'ST';
    const age = parseInt(document.getElementById('age')?.value) || 18;

    try {
        const res = await fetch((window.FPS_API_URL || '/api') + '/career/create', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ firstName, lastName, position, age })
        });

        if (!res.ok) {
            const err = await res.json();
            alert('Błąd tworzenia postaci: ' + (err.error || 'Nieznany błąd'));
            return;
        }

        const data = await res.json();
        gameState = data.state;
        updateUI();
        showToast('Kariera rozpoczęta!');
    } catch (e) {
        console.error(e);
        alert('Błąd połączenia z serwerem!');
    }
};

// 2. Główna funkcja odświeżająca interfejs
function updateUI() {
    if (!gameState || !gameState.created) return;

    document.getElementById('onboarding')?.classList.add('hidden');
    document.getElementById('game')?.classList.remove('hidden');

    if (gameState.offers && gameState.offers.length > 0 && !gameState.club?.name) {
        renderOffersModal(gameState.offers);
    } else {
        const modal = document.getElementById('modal');
        if (modal) modal.classList.add('hidden');
    }

    // Renderujemy aktywną zakładkę
    const activeBtn = document.querySelector('#nav button.active');
    const screenName = activeBtn ? activeBtn.getAttribute('data-screen') : 'home';
    renderScreen(screenName);
}

// 3. Router renderujący odpowiednią zakładkę
function renderScreen(screenName) {
    switch (screenName) {
        case 'home': renderHomeScreen(); break;
        case 'career': renderCareerScreen(); break;
        case 'club': renderClubScreen(); break;
        case 'world': renderWorldScreen(); break;
        case 'cups': renderCupsScreen(); break;
        case 'national': renderNationalScreen(); break;
        case 'profile': renderProfileScreen(); break;
    }
}

// --- RENDEROWANIE ZAKŁADEK ---

// GŁÓWNA
function renderHomeScreen() {
    const s = document.getElementById('screen-home');
    if (!s) return;

    const p = gameState.player || {};
    const c = gameState.club || {};
    const cal = gameState.calendar || {};
    const stats = gameState.stats || {};
    const news = gameState.news || [];

    s.innerHTML = `
        <div class="hero-card">
            <h1>${p.name || 'Zawodnik'} (${p.position || '-'})</h1>
            <p>Klub: <strong>${c.name || 'Wolny agent'}</strong> | OVR: <strong>${p.ovr || 0}</strong> | Potencjał: <strong>${p.potential || 0}</strong></p>
            <p style="font-size: 0.8rem; color: var(--accent-neon); margin-top: 6px;">Sezon: ${cal.season || '2026/27'} | Kolejka: ${cal.matchday || 1}/${cal.totalMatchdays || 30}</p>
        </div>

        <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px; margin-bottom: 12px;">
            <div style="font-size: 0.75rem; font-weight:700; color: var(--text-muted); margin-bottom: 10px;">STATYSTYKI KARIERY</div>
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; text-align: center;">
                <div><div style="font-weight:800; font-size: 1.2rem;">${stats.matches || 0}</div><small style="font-size:0.65rem; color: var(--text-muted);">Mecze</small></div>
                <div><div style="font-weight:800; font-size: 1.2rem; color: var(--accent-green);">${stats.goals || 0}</div><small style="font-size:0.65rem; color: var(--text-muted);">Gole</small></div>
                <div><div style="font-weight:800; font-size: 1.2rem; color: #3b82f6;">${stats.assists || 0}</div><small style="font-size:0.65rem; color: var(--text-muted);">Asysty</small></div>
                <div><div style="font-weight:800; font-size: 1.2rem; color: #f59e0b;">${p.form || 0}</div><small style="font-size:0.65rem; color: var(--text-muted);">Forma</small></div>
            </div>
        </div>

        ${p.injured ? `<button class="primary" onclick="playerRehab()" style="background: #ef4444; margin-bottom: 10px;">🚑 REHABILITACJA (15,000 PLN)</button>` : ''}
        
        <button class="primary" onclick="simulateWeek()" style="margin-bottom: 10px;">ROZEGRAJ KOLEJKĘ / MECZ</button>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 16px;">
            <button class="ghost" onclick="trainPlayer('TECHNIQUE')">🏋️ TRENING (TECH)</button>
            <button class="ghost" onclick="trainPlayer('PHYSICAL')">💪 TRENING (FIZ)</button>
        </div>

        <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px;">
            <div style="font-size: 0.75rem; font-weight:700; color: var(--text-muted); margin-bottom: 10px;">WIADOMOŚCI</div>
            ${news.slice(0, 4).map(n => `<div style="font-size: 0.8rem; margin-bottom: 6px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 4px;">${n.text}</div>`).join('')}
        </div>
    `;
}

// KARIERA
function renderCareerScreen() {
    const s = document.getElementById('screen-career');
    if (!s) return;

    const perks = gameState.perks || [];
    const sp = gameState.skillPoints || 0;
    const history = gameState.seasonHistory || [];

    s.innerHTML = `
        <div class="hero-card" style="margin-bottom: 12px;">
            <h2>Rozwój i Umiejętności</h2>
            <p>Punkty Umiejętności: <strong style="color: var(--accent-neon);">${sp} PKT</strong></p>
        </div>

        <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px; margin-bottom: 16px;">
            <div style="font-size: 0.75rem; font-weight:700; color: var(--text-muted); margin-bottom: 10px;">PERKI / ATUTY</div>
            ${perks.map(p => `
                <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.03); padding:10px; margin-bottom:6px; border-radius:8px;">
                    <div>
                        <div style="font-weight:700; font-size:0.85rem;">${p.name}</div>
                        <small style="color:var(--text-muted); font-size:0.7rem;">${p.desc}</small>
                    </div>
                    ${p.unlocked ? `<span style="color:var(--accent-green); font-weight:700; font-size:0.8rem;">Odblokowane</span>` : 
                    `<button class="primary" style="padding:6px 12px; font-size:0.75rem;" onclick="unlockPerk('${p.id}')">Kup (${p.cost} pkt)</button>`}
                </div>
            `).join('')}
        </div>

        <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px;">
            <div style="font-size: 0.75rem; font-weight:700; color: var(--text-muted); margin-bottom: 10px;">HISTORIA SEZONÓW</div>
            ${history.length === 0 ? '<p style="font-size:0.8rem; color:var(--text-muted);">Brak historii. Dokończ pierwszy sezon!</p>' :
            history.map(h => `<div style="font-size:0.8rem; margin-bottom:6px;">Sezon ${h.season}: ${h.club} | OVR: ${h.ovrBefore}→${h.ovrAfter} | Gole: ${h.goals}</div>`).join('')}
        </div>
    `;
}

// KLUB
async function renderClubScreen() {
    const s = document.getElementById('screen-club');
    if (!s) return;

    s.innerHTML = `<div style="text-align:center; padding:20px;">Wczytywanie składu...</div>`;

    try {
        const res = await fetch((window.FPS_API_URL || '/api') + '/squad');
        const squad = await res.json();

        s.innerHTML = `
            <div class="hero-card" style="margin-bottom: 12px;">
                <h2>Skład Zespołu: ${gameState.club?.name || ''}</h2>
                <p>Zgranie zespołu: <strong>${gameState.teamChemistry || 70}%</strong></p>
            </div>

            <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px; margin-bottom: 12px;">
                <div style="font-size: 0.75rem; font-weight:700; color: var(--accent-green); margin-bottom: 10px;">WYJŚCIOWA 11</div>
                ${squad.starting.map(p => `<div style="font-size:0.85rem; padding:4px 0; ${p.mine ? 'font-weight:800; color:var(--accent-neon);' : ''}">${p.number}. ${p.name} (${p.position}) - OVR: ${p.ovr}</div>`).join('')}
            </div>

            <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px;">
                <div style="font-size: 0.75rem; font-weight:700; color: #f59e0b; margin-bottom: 10px;">ŁAWKA REZERWOWYCH</div>
                ${squad.bench.map(p => `<div style="font-size:0.85rem; padding:4px 0; ${p.mine ? 'font-weight:800; color:var(--accent-neon);' : ''}">${p.number}. ${p.name} (${p.position}) - OVR: ${p.ovr}</div>`).join('')}
            </div>
        `;
    } catch (e) {
        s.innerHTML = `<div style="text-align:center; color:#ef4444;">Błąd pobierania składu</div>`;
    }
}

// ŚWIAT
async function renderWorldScreen() {
    const s = document.getElementById('screen-world');
    if (!s) return;

    s.innerHTML = `<div style="text-align:center; padding:20px;">Wczytywanie tabeli ligowej...</div>`;

    try {
        const res = await fetch((window.FPS_API_URL || '/api') + '/table');
        const table = await res.json();

        s.innerHTML = `
            <div class="hero-card" style="margin-bottom: 12px;">
                <h2>Tabela Ligowa: ${gameState.club?.league || ''}</h2>
            </div>

            <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 12px; overflow-x: auto;">
                <table style="width:100%; border-collapse:collapse; font-size:0.8rem;">
                    <thead>
                        <tr style="text-align:left; color:var(--text-muted); border-bottom:1px solid rgba(255,255,255,0.1);">
                            <th style="padding:6px;">#</th>
                            <th>Klub</th>
                            <th>M</th>
                            <th>PKT</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${table.map(r => `
                            <tr style="border-bottom:1px solid rgba(255,255,255,0.03); ${r.mine ? 'background:rgba(139, 92, 246, 0.2); font-weight:800;' : ''}">
                                <td style="padding:6px;">${r.pos}</td>
                                <td>${r.club}</td>
                                <td>${r.played}</td>
                                <td><strong>${r.pts}</strong></td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (e) {
        s.innerHTML = `<div style="text-align:center; color:#ef4444;">Błąd pobierania tabeli</div>`;
    }
}

// PUCHARY
function renderCupsScreen() {
    const s = document.getElementById('screen-cups');
    if (!s) return;

    const trophies = gameState.trophies || [];
    const cup = gameState.cup || {};

    s.innerHTML = `
        <div class="hero-card" style="margin-bottom: 12px;">
            <h2>Rozgrywki Pucharowe</h2>
        </div>

        <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px; margin-bottom: 12px;">
            <div style="font-size: 0.75rem; font-weight:700; color: var(--text-muted); margin-bottom: 8px;">PUCHAR POLSKI</div>
            <p style="font-size:0.85rem;">Status: <strong>${cup.finished ? 'Zakończony (Mistrz: ' + cup.champion + ')' : 'W trakcie (Runda ' + cup.rounds + ')'}</strong></p>
        </div>

        <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px;">
            <div style="font-size: 0.75rem; font-weight:700; color: var(--text-muted); margin-bottom: 8px;">TWOJE TROFEA</div>
            ${trophies.length === 0 ? '<p style="font-size:0.8rem; color:var(--text-muted);">Brak trofeów. Zdobądź swoje pierwsze mistrzostwo!</p>' :
            trophies.map(t => `<div style="font-size:0.85rem; padding:4px 0;">🏆 ${t.name} (${t.season})</div>`).join('')}
        </div>
    `;
}

// KRAJ
function renderNationalScreen() {
    const s = document.getElementById('screen-national');
    if (!s) return;

    const nat = gameState.national || {};

    s.innerHTML = `
        <div class="hero-card" style="margin-bottom: 12px;">
            <h2>🇵🇱 Reprezentacja Polski</h2>
        </div>

        <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px;">
            ${Object.entries(nat).map(([tier, data]) => `
                <div style="margin-bottom:12px; padding-bottom:8px; border-bottom:1px solid rgba(255,255,255,0.05);">
                    <div style="font-weight:700; font-size:0.9rem;">Kadra: ${tier}</div>
                    <div style="font-size:0.8rem; color:${data.called ? 'var(--accent-green)' : 'var(--text-muted)'};">
                        ${data.called ? 'STATUS: Powołany! 🇵🇱' : 'STATUS: Brak powołania (Wymagany OVR >= 65)'}
                    </div>
                    ${data.lastResult ? `<div style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">Ostatni mecz: ${data.lastResult}</div>` : ''}
                </div>
            `).join('')}
        </div>
    `;
}

// PROFIL
function renderProfileScreen() {
    const s = document.getElementById('screen-profile');
    if (!s) return;

    const fin = gameState.finances || {};
    const rel = gameState.relationships || {};
    const sponsors = gameState.sponsors || [];
    const activeSp = gameState.activeSponsor;

    s.innerHTML = `
        <div class="hero-card" style="margin-bottom: 12px;">
            <h2>Profil & Finanse</h2>
            <p>Stan konta: <strong style="color:var(--accent-green);">${(fin.balance || 0).toLocaleString()} PLN</strong></p>
            <p>Tygodniówka: <strong>${(fin.salary || 0).toLocaleString()} PLN</strong></p>
        </div>

        <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px; margin-bottom: 12px;">
            <div style="font-size: 0.75rem; font-weight:700; color: var(--text-muted); margin-bottom: 8px;">RELACJE</div>
            <div style="font-size:0.85rem; margin-bottom:4px;">Zaufanie Trenera: <strong>${rel.managerTrust || 50}%</strong></div>
            <div style="font-size:0.85rem;">Poparcie Kibiców: <strong>${rel.fanApproval || 50}%</strong></div>
        </div>

        <div style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px; padding: 16px; margin-bottom: 12px;">
            <div style="font-size: 0.75rem; font-weight:700; color: var(--text-muted); margin-bottom: 8px;">SPONSORZY</div>
            ${sponsors.slice(0, 3).map(sp => `
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                    <div style="font-size:0.8rem;">${sp.name} (${sp.pay} PLN/tyg)</div>
                    ${activeSp === sp.id ? `<span style="color:var(--accent-green); font-size:0.75rem;">Aktywny</span>` :
                    `<button class="ghost" style="padding:4px 8px; font-size:0.7rem;" onclick="signSponsor('${sp.id}')">Podpisz</button>`}
                </div>
            `).join('')}
        </div>

        <button class="ghost" style="color:#ef4444; border-color:rgba(239,68,68,0.3); width:100%;" onclick="retireCareer()">PRZEJDŹ NA EMERYTURĘ</button>
    `;
}

// --- AKCJE API ---

function renderOffersModal(offers) {
    const modal = document.getElementById('modal');
    const modalContent = document.getElementById('modalContent');
    if (!modal || !modalContent) return;

    let html = `<h2 style="margin-bottom: 12px; font-size: 1.3rem;">Wybierz swój klub startowy</h2>`;
    offers.forEach(o => {
        html += `
            <div style="background: rgba(255,255,255,0.05); border: 1px solid var(--border-color); padding: 12px; margin-bottom: 10px; border-radius: 12px;">
                <div style="font-weight: 800; font-size: 1.1rem; color: #fff;">${o.club}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 2px;">Liga: ${o.league} | OVR: ${o.ovr}</div>
                <div style="font-weight: 700; color: var(--accent-green); margin: 6px 0;">${(o.wage || 0).toLocaleString()} PLN / tyg.</div>
                <button class="primary" style="padding: 10px; font-size: 0.85rem;" onclick="acceptOffer('${o.clubId}')">Podpisz kontrakt</button>
            </div>
        `;
    });

    modalContent.innerHTML = html;
    modal.classList.remove('hidden');
}

window.acceptOffer = async function(clubId) {
    try {
        const res = await fetch((window.FPS_API_URL || '/api') + '/career/accept', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ clubId })
        });
        if (!res.ok) throw new Error('Błąd dołączania do klubu');

        gameState = await res.json();
        updateUI();
        showToast('Dołączono do klubu!');
    } catch (e) { alert(e.message); }
};

window.simulateWeek = async function() {
    try {
        const res = await fetch((window.FPS_API_URL || '/api') + '/match/simulate', { method: 'POST' });
        if (!res.ok) {
            const err = await res.json();
            alert(err.error || 'Błąd symulacji');
            return;
        }
        const data = await res.json();
        gameState = data.state;
        updateUI();
        showToast('Kolejka zakończona!');
    } catch (e) { alert('Błąd połączenia z serwerem'); }
};

window.trainPlayer = async function(focus) {
    try {
        const res = await fetch((window.FPS_API_URL || '/api') + '/training', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ focus })
        });
        if (!res.ok) {
            const err = await res.json();
            alert(err.error || 'Błąd treningu');
            return;
        }
        gameState = await res.json();
        updateUI();
        showToast('Trening wykonany!');
    } catch (e) { alert('Błąd połączenia z serwerem'); }
};

window.unlockPerk = async function(perkId) {
    try {
        const res = await fetch((window.FPS_API_URL || '/api') + '/perk/unlock', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ perkId })
        });
        if (!res.ok) {
            const err = await res.json();
            alert(err.error || 'Błąd odblokowania perku');
            return;
        }
        gameState = await res.json();
        updateUI();
        showToast('Odblokowano perk!');
    } catch (e) { alert('Błąd połączenia z serwerem'); }
};

window.playerRehab = async function() {
    try {
        const res = await fetch((window.FPS_API_URL || '/api') + '/player/rehab', { method: 'POST' });
        if (!res.ok) {
            const err = await res.json();
            alert(err.error || 'Błąd rehabilitacji');
            return;
        }
        gameState = await res.json();
        updateUI();
        showToast('Rehabilitacja pomyślna!');
    } catch (e) { alert('Błąd połączenia z serwerem'); }
};

window.signSponsor = async function(sponsorId) {
    try {
        const res = await fetch((window.FPS_API_URL || '/api') + '/sponsor/sign', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sponsorId })
        });
        if (!res.ok) {
            const err = await res.json();
            alert(err.error || 'Błąd podpisywania umowy');
            return;
        }
        gameState = await res.json();
        updateUI();
        showToast('Podpisano umowę ze sponsorem!');
    } catch (e) { alert('Błąd połączenia z serwerem'); }
};

window.retireCareer = async function() {
    if (!confirm('Czy na pewno chcesz zakończyć karierę?')) return;
    try {
        const res = await fetch((window.FPS_API_URL || '/api') + '/career/retire', { method: 'POST' });
        gameState = await res.json();
        updateUI();
        alert('Kariera zakończona!');
    } catch (e) { alert('Błąd połączenia z serwerem'); }
};

function showToast(text) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.innerText = text;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

// 4. Przełączanie nawigacji dolnej
document.addEventListener('DOMContentLoaded', () => {
    const navButtons = document.querySelectorAll('#nav button');
    navButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const screenName = btn.getAttribute('data-screen');
            navButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
            const targetScreen = document.getElementById(`screen-${screenName}`);
            if (targetScreen) targetScreen.classList.add('active');

            // Renderujemy treść zakładki po przełączeniu
            renderScreen(screenName);
        });
    });
});
