window.APP_CONFIG = {
  API_BASE_URL: "", // Pusty adres – brak połączenia z serwerem Render
  IS_OFFLINE_MODE: true
};
