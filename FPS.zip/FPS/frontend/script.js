window.addEventListener('error', e => { 
  console.error(e.error || e.message); 
});

const SETTINGS_KEY = 'fps_ui_settings';
let currentWorldLeague = 'Ekstraklasa';

const LEAGUES_DATA = {
  'Ekstraklasa': ['Legia Warszawa', 'Lech Poznań', 'Raków Częstochowa', 'Pogoń Szczecin', 'Jagiellonia Białystok', 'Śląsk Wrocław', 'Górnik Zabrze', 'Widzew Łódź', 'Cracovia', 'Piast Gliwice', 'Zagłębie Lubin', 'Warta Poznań', 'Radomiak Radom', 'Korona Kielce', 'Stal Mielec', 'Puszcza Niepołomice', 'Ruch Chorzów', 'ŁKS Łódź'],
  '1. Liga': ['Wisła Kraków', 'Lechia Gdańsk', 'Arka Gdynia', 'Motor Lublin', 'GKS Katowice', 'Odra Opole', 'Górnik Łęczna', 'Miedź Legnica', 'Polonia Warszawa', 'Znicz Pruszków'],
  '2. Liga': ['KKS 1925 Kalisz', 'Kotwica Kołobrzeg', 'Radunia Stężyca', 'Hutnik Kraków', 'Chojniczanka', 'Olimpia Elbląg', 'Stal Stalowa Wola', 'ŁKS II Łódź'],
  '3. Liga': ['MKS Kluczbork', 'Rekord Bielsko-Biała', 'Śląsk II Wrocław', 'Goczałkowice Zdrój', 'Carina Gubin', 'Star Starachowice']
};

function loadSettings() {
  const defaults = { animations: true, sound: true, music: true, volume: 0.7, theme: 'dark' };
  try {
    return { ...defaults, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') };
  } catch (e) {
    return defaults;
  }
}

let uiSettings = loadSettings();

function applySettings() {
  document.documentElement.setAttribute('data-theme', uiSettings.theme);
  document.body.classList.toggle('no-animations', !uiSettings.animations);
}

function saveSettings() {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(uiSettings)); } catch (e) {}
}

applySettings();

let S = null;
let toastTimer = null;

const $ = id => document.getElementById(id);

const esc = x => String(x ?? '').replace(/[&<>"']/g, m => ({ 
  '&': '&amp;', 
  '<': '&lt;', 
  '>': '&gt;', 
  '"': '&quot;', 
  "'": '&#39;' 
}[m]));

function toast(t) {
  const el = $('toast');
  if (!el) return;
  if (toastTimer) clearTimeout(toastTimer);
  
  el.textContent = t;
  el.classList.remove('show');
  void el.offsetWidth;
  el.classList.add('show');
  toastTimer = setTimeout(() => el.classList.remove('show'), 2400);
}

function vib(pattern = 18) {
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function' && !/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
      navigator.vibrate(pattern);
    }
  } catch (e) {}
}

const SFX_FILES = {
  click:   'audio/sfx_click.mp3',   
  whistle: 'audio/sfx_whistle.mp3', 
  goal:    'audio/sfx_goal.mp3',    
  perk:    'audio/sfx_perk.mp3',    
  trophy:  'audio/sfx_trophy.mp3',  
};

const MUSIC_FILES = {
  menu: 'audio/menu_music.mp3',   
  game: 'audio/game_ambient.mp3', 
};

const sfxCache = {};
function playSfx(name) {
  if (!uiSettings.sound) return;
  const src = SFX_FILES[name];
  if (!src) return;
  try {
    const base = sfxCache[name] || (sfxCache[name] = new Audio(src));
    const el = base.cloneNode();
    el.volume = uiSettings.volume ?? 0.7;
    el.play().catch(() => {});
  } catch (e) {}
}

const musicEls = { menu: null, game: null };
let currentMusicKey = null;

function getMusicEl(key) {
  if (!musicEls[key]) {
    const el = new Audio(MUSIC_FILES[key]);
    el.loop = true;
    musicEls[key] = el;
  }
  return musicEls[key];
}

function applyMusicVolume() {
  const vol = (uiSettings.volume ?? 0.7) * 0.5;
  Object.values(musicEls).forEach(el => { if (el) el.volume = vol; });
}

function playMusic(key) {
  if (!uiSettings.music) { stopMusic(); currentMusicKey = key; return; }
  if (currentMusicKey === key && musicEls[key] && !musicEls[key].paused) return;

  Object.entries(musicEls).forEach(([k, el]) => { if (el && k !== key) el.pause(); });

  const el = getMusicEl(key);
  applyMusicVolume();
  el.play().catch(() => {});
  currentMusicKey = key;
}

function stopMusic() {
  Object.values(musicEls).forEach(el => { if (el) el.pause(); });
}

function updateMusicForPanel(id) {
  if (id === 'game') {
    playMusic('game');
  } else {
    playMusic('menu');
  }
}

let musicArmed = false;
function armMusicOnFirstGesture() {
  if (musicArmed) return;
  musicArmed = true;
  if (uiSettings.music) {
    playMusic(currentMusicKey || 'menu');
  }
}

document.addEventListener('click', (e) => {
  armMusicOnFirstGesture();
  if (e.target.tagName === 'BUTTON' || e.target.closest('button')) {
    playSfx('click');
  }
});

const NAV_ORDER = ['home', 'career', 'club', 'world', 'cups', 'national', 'profile'];
let currentScreenName = 'home';

function showPanel(id) {
  document.querySelectorAll('.panel-screen').forEach(el => {
    if (el.id !== 'splash') {
      el.classList.remove('show', 'active');
      el.classList.add('hidden');
      el.style.display = 'none';
    }
  });
  
  const el = $(id);
  if (el) {
    el.classList.remove('hidden');
    el.classList.add('show', 'active');
    el.style.display = 'block';
  }
  updateMusicForPanel(id);
}

function openGame() {
  closeModal(true);
  showPanel('game');
  currentScreenName = 'home';
  renderAll();
}

function showModal(html) {
  const m = $('modal');
  const mc = $('modalContent');
  if (mc) mc.innerHTML = html;
  if (m) {
    m.classList.remove('hidden', 'closing');
    m.style.display = 'flex';
  }
}

window.closeModal = function(instant = false) {
  const m = $('modal');
  if (!m || m.classList.contains('hidden')) return;
  
  if (instant) {
    m.classList.add('hidden');
    m.classList.remove('closing');
    m.style.display = 'none';
    const mc = $('modalContent');
    if (mc) mc.innerHTML = '';
    return;
  }

  m.classList.add('closing');
  m.addEventListener('animationend', function handler() {
    m.classList.add('hidden');
    m.classList.remove('closing');
    m.style.display = 'none';
    const mc = $('modalContent');
    if (mc) mc.innerHTML = '';
    m.removeEventListener('animationend', handler);
  }, { once: true });
};

function nav(name) {
  currentScreenName = name;
  document.querySelectorAll('#nav button').forEach(b => {
    b.classList.toggle('active', b.dataset.screen === name);
  });

  document.querySelectorAll('.screen').forEach(s => {
    s.classList.remove('active');
  });

  const newEl = $(`screen-${name}`);
  if (newEl) {
    newEl.classList.add('active');
  }

  renderScreen(name);
  vib(10);
}

function generateStandingsForLeague(leagueName, myClubName) {
  const teams = LEAGUES_DATA[leagueName] || LEAGUES_DATA['3. Liga'];
  return teams.map((team, idx) => ({
    pos: idx + 1,
    name: team,
    pts: Math.max(0, 30 - idx * 2),
    isPlayer: team === myClubName
  }));
}

window.startCareer = async function(event) {
  if (event) event.preventDefault();

  const payload = {
    firstName: $('firstName')?.value.trim() || 'Mateusz',
    lastName: $('lastName')?.value.trim() || 'Kowalski',
    position: $('position')?.value || 'ST',
    age: Number($('age')?.value || 18)
  };

  if (!payload.firstName || !payload.lastName) {
    return toast('Wpisz imię i nazwisko');
  }

  S = {
    player: {
      name: `${payload.firstName} ${payload.lastName}`,
      position: payload.position,
      age: payload.age,
      ovr: 60,
      condition: 100
    },
    stats: { matches: 0, goals: 0, assists: 0, minutes: 0 },
    calendar: { season: '2025/2026', matchday: 1, totalMatchdays: 30 },
    relationships: { managerTrust: 50 },
    finances: { balance: 0 },
    club: { id: 'c3_1', name: 'MKS Kluczbork', league: '3. Liga (Gr. 3)', position: 1 },
    standings: generateStandingsForLeague('3. Liga', 'MKS Kluczbork')
  };

  openOffers(S?.offers);
};

function openOffers(rawOffers) {
  const initialPolishOffers = [
    { clubId: 'c3_1', club: 'MKS Kluczbork', league: '3. Liga (Gr. 3)', wage: 800 },
    { clubId: 'c2_1', club: 'KKS 1925 Kalisz', league: '2. Liga Polska', wage: 1500 },
    { clubId: 'c2_2', club: 'Olimpia Elbląg', league: '2. Liga Polska', wage: 1700 },
    { clubId: 'c1_1', club: 'Polonia Warszawa', league: '1. Liga Polska', wage: 2800 }
  ];

  const offers = (rawOffers && rawOffers.length >= 4) ? rawOffers : initialPolishOffers;

  const html = `
    <div class="eyebrow">PIERWSZY KONTRAKT</div>
    <h2 style="color:#fff; margin-bottom:8px;">Wybierz swój pierwszy klub</h2>
    <p class="muted" style="margin-bottom:16px;">Zacznij karierę w niższych ligach i przebij się na szczyt.</p>
    <div style="max-height: 50vh; overflow-y: auto; padding-right: 4px;">
      ${offers.map((o, idx) => `
        <button class="ghost offer-btn" data-index="${idx}" style="width:100%; margin-bottom:8px; text-align:left; border-radius:12px;">
          <b>${esc(o.club)}</b><br>
          <span style="font-size:0.75rem; color:var(--text-muted);">
            ${o.league ? esc(o.league) + ' • ' : ''} Oferowana pensja: ${o.wage ? Number(o.wage).toLocaleString() : 0} PLN/tydz.
          </span>
        </button>
      `).join('')}
    </div>
  `;

  showModal(html);

  document.querySelectorAll('.offer-btn').forEach(b => {
    b.onclick = () => {
      const idx = Number(b.dataset.index);
      const o = offers[idx];
      openNegotiationModal(o.clubId || o.club, o.club, o.league || 'Polska Liga', o.wage || 1000);
    };
  });
}

window.openNegotiationModal = function(clubId, clubName, clubLeague, baseWage, initialPatience = 100, alertMsg = '') {
  const html = `
    <div class="eyebrow">NEGOCJACJE KONTRAKTU</div>
    <h2 style="color:#fff; margin-bottom:4px;">${esc(clubName)}</h2>
    <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:12px;">
      Cierpliwość zarządu: <b style="color:${initialPatience > 50 ? 'var(--accent-green)' : '#ef4444'};">${initialPatience}%</b>
    </p>

    ${alertMsg ? `<div style="background:rgba(239, 68, 68, 0.15); border:1px solid #ef4444; color:#fff; padding:8px 12px; border-radius:8px; font-size:0.75rem; margin-bottom:12px;">${alertMsg}</div>` : ''}

    <div style="margin-bottom:10px;">
      <label style="font-size:0.75rem; color:var(--text-muted);">ŻĄDANA PENSJA TYGODNIOWA (PLN):</label>
      <input type="number" id="neg-wage" value="${baseWage}" style="width:100%; padding:10px; margin-top:4px; background:rgba(0,0,0,0.3); border:1px solid var(--border-color); color:#fff; border-radius:8px; font-weight:bold;">
    </div>

    <button id="btn-submit-contract" class="action primaryAction" style="width:100%; padding:12px; margin-top:4px;">
      📑 PRZEDSTAW WARUNKI
    </button>
    <button class="action" style="width:100%; margin-top:6px;" onclick="closeModal()">ANULUJ</button>
  `;

  showModal(html);

  const btn = $('btn-submit-contract');
  if (btn) {
    btn.onclick = () => window.submitContractOffer(clubId, clubName, clubLeague, initialPatience);
  }
};

window.submitContractOffer = async function(clubId, clubName, clubLeague, patience) {
  const wage = Number($('neg-wage')?.value || 0);

  if (S) {
    S.club = { id: clubId, name: clubName, league: clubLeague || 'Polska Liga', position: 1 };
    S.finances = { balance: wage * 4 };
    
    let baseLeagueKey = '3. Liga';
    if (clubLeague.includes('2.')) baseLeagueKey = '2. Liga';
    if (clubLeague.includes('1.')) baseLeagueKey = '1. Liga';
    if (clubLeague.includes('Ekstraklasa')) baseLeagueKey = 'Ekstraklasa';

    S.standings = generateStandingsForLeague(baseLeagueKey, clubName);
    currentWorldLeague = baseLeagueKey;
    localStorage.setItem('fps_offline_db', JSON.stringify(S));
  }

  closeModal(true);
  playSfx('trophy');
  vib([30, 50, 30]);
  toast(`Podpisano kontrakt z ${clubName}!`);
  openGame();
};

async function saveGame() {
  if (S) {
    const dataStr = JSON.stringify(S);
    localStorage.setItem('fps_offline_db', dataStr);
    localStorage.setItem('fps_slot1', dataStr);
    toast('Zapisano karierę lokalnie');
    vib(20);
  }
}

function renderAll() {
  if (!S) return;
  
  if (S.calendar && S.club) {
    const sLabel = $('seasonLabel');
    const cLabel = $('clubLabel');
    if (sLabel) sLabel.textContent = `${S.calendar.season} • KOLEJKA ${S.calendar.matchday}/${S.calendar.totalMatchdays || 30}`;
    if (cLabel) cLabel.textContent = S.club.name || '—';
  }
  
  renderScreen(currentScreenName);
}

window.renderAll = renderAll;

function renderScreen(name) {
  if (!S) return;
  ({
    home: renderHome, 
    career: renderCareer, 
    club: renderClub,
    world: renderWorld, 
    cups: renderCups, 
    national: renderNational, 
    profile: renderProfile
  }[name] || renderHome)();
}

function initials(name) {
  return String(name || '?').split(' ').filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

function renderHome() {
  const trust = S.relationships?.managerTrust ?? 50;
  const condition = S.player?.condition ?? 100;

  const currentLeagueTeams = LEAGUES_DATA[currentWorldLeague] || LEAGUES_DATA['3. Liga'];
  const opponent = currentLeagueTeams.find(t => t !== S.club?.name) || 'Rywal';

  $('screen-home').innerHTML = `
    <div class="hero-card">
      <div class="eyebrow">${esc(S.club?.league || 'Liga')} • ${S.club?.position || 1}. MIEJSCE</div>
      <div class="matchline">
        <div>
          <div class="name">${esc(S.player?.name || 'Gracz')}</div>
          <p>${S.player?.age || 18} lat • ${esc(S.player?.position || 'ST')} • #${S.player?.number || 10}</p>
        </div>
        <div class="ovr">${S.player?.ovr || 60}<small>OVR</small></div>
      </div>
      <div class="stat-row">
        <div class="labels"><span class="lbl">Dyspozycja</span><span class="val">${condition}%</span></div>
        <div class="track"><div class="home" style="width:${condition}%"></div></div>
      </div>
    </div>

    <div class="hero-card match-card">
      <div class="eyebrow live"><span class="dot"></span>NASTĘPNY MECZ</div>
      <div class="badge-row">
        <div class="crest">${initials(S.club?.name)}</div>
        <div class="score-block">
          <div class="score">VS</div>
          <div class="sub">${esc(S.calendar?.season || '2025/2026')}</div>
        </div>
        <div class="crest">${initials(opponent)}</div>
      </div>
      <div class="team-names"><b>${esc(S.club?.name || '—')}</b><span>KOLEJKA ${S.calendar?.matchday || 1}</span><b>${esc(opponent)}</b></div>
      <button class="primary" style="margin-top:16px;" onclick="window.simulateMatch('${esc(opponent)}')">▶ ROZEGRAJ MECZ</button>
      <button class="ghost" style="margin-top:8px;" onclick="window.trainingModal()">🏋️ TRENING</button>
    </div>

    <div class="hero-card">
      <div class="eyebrow">STATUS KLUBOWY</div>
      <div class="statgrid">
        <div class="mini">
          <span>Portfel</span>
          <b>${(S.finances?.balance || 0).toLocaleString()} PLN</b>
        </div>
        <div class="mini">
          <span>Zaufanie trenera</span>
          <b>${trust}/100</b>
          <div class="meter"><span style="width:${trust}%"></span></div>
        </div>
      </div>
    </div>
  `;
}

/* ROZBUDOWANY SILNIK SYMULACJI MECZU */
window.simulateMatch = function(opponent) {
  playSfx('whistle');
  
  let myGoals = 0;
  let oppGoals = 0;
  let playerGoals = 0;
  let playerAssists = 0;
  let logs = [];

  const playerChance = ((S.player?.ovr || 60) / 100) * 0.35;

  for (let min = 1; min <= 90; min += Math.floor(Math.random() * 14) + 1) {
    const rand = Math.random();
    if (rand < 0.08) {
      myGoals++;
      if (Math.random() < playerChance) {
        playerGoals++;
        logs.push(`<div class="log-item goal" style="color:var(--accent-neon); margin-bottom:4px;">⚽ <b>${min}' GOOOL!</b> Bramkę zdobywa <b>${esc(S.player?.name)}</b>!</div>`);
      } else if (Math.random() < 0.3) {
        playerAssists++;
        logs.push(`<div class="log-item goal" style="color:var(--accent-neon); margin-bottom:4px;">⚽ <b>${min}' GOOL!</b> Trafienie dla ${esc(S.club?.name)} po asyście ${esc(S.player?.name)}!</div>`);
      } else {
        logs.push(`<div class="log-item" style="margin-bottom:4px;">⚽ <b>${min}' GOL!</b> Zespół ${esc(S.club?.name)} trafia do siatki!</div>`);
      }
    } else if (rand > 0.92) {
      oppGoals++;
      logs.push(`<div class="log-item" style="color:#ef4444; margin-bottom:4px;">⚽ <b>${min}' GOL!</b> ${esc(opponent)} zdobywa bramkę.</div>`);
    } else if (rand > 0.45 && rand < 0.48) {
      logs.push(`<div class="log-item" style="color:var(--text-muted); margin-bottom:4px;">🟨 <b>${min}'</b> Żółta karta po ostrej walce w środku pola.</div>`);
    }
  }

  if (!S.stats) S.stats = { matches: 0, goals: 0, assists: 0, minutes: 0 };
  S.stats.matches += 1;
  S.stats.goals += playerGoals;
  S.stats.assists += playerAssists;
  S.stats.minutes += 90;

  if (!S.calendar) S.calendar = { matchday: 1 };
  S.calendar.matchday += 1;

  if (S.standings) {
    let myTeam = S.standings.find(t => t.name === S.club?.name);
    if (myTeam) {
      if (myGoals > oppGoals) myTeam.pts += 3;
      else if (myGoals === oppGoals) myTeam.pts += 1;
    }
    S.standings.sort((a, b) => b.pts - a.pts);
    S.standings.forEach((t, i) => t.pos = i + 1);
    
    myTeam = S.standings.find(t => t.name === S.club?.name);
    if (myTeam && S.club) S.club.position = myTeam.pos;
  }

  localStorage.setItem('fps_offline_db', JSON.stringify(S));

  playSfx('goal');
  vib([30, 50, 30]);

  const html = `
    <div class="eyebrow">KONIEC MECZU</div>
    <h2 style="color:#fff; text-align:center; margin-bottom:12px;">${esc(S.club?.name)} ${myGoals} : ${oppGoals} ${esc(opponent)}</h2>
    <div style="background:rgba(255,255,255,0.05); padding:10px; border-radius:12px; text-align:center; margin-bottom:12px; font-size:0.85rem;">
      Wkład w mecz: <b>${playerGoals} Goli, ${playerAssists} Asyst</b>
    </div>
    <div style="max-height:180px; overflow-y:auto; background:rgba(0,0,0,0.3); padding:10px; border-radius:10px; font-size:0.75rem; border:1px solid var(--border-soft);">
      ${logs.length ? logs.join('') : '<div style="color:var(--text-muted);">Mecz przebiegł bez większych spięć pod bramkami.</div>'}
    </div>
    <button class="primary" style="margin-top:14px;" onclick="closeModal(true); renderAll();">KONTYNUUJ</button>
  `;

  showModal(html);
};

window.trainingModal = async function() {
  if (S && S.player) {
    S.player.ovr = (S.player.ovr || 60) + 1;
    localStorage.setItem('fps_offline_db', JSON.stringify(S));
  }

  playSfx('perk');
  toast('Trening zaliczony! OVR +1');
  vib(18);
  renderAll();
};

function renderCareer() {
  const matches = S.stats?.matches || 0;
  const goals = S.stats?.goals || 0;
  const assists = S.stats?.assists || 0;
  const minutes = S.stats?.minutes || 0;
  $('screen-career').innerHTML = `
    <div class="topbar"><h2>Twoja kariera</h2></div>
    <div class="hero-card">
      <div class="eyebrow">SEZON ${esc(S.calendar?.season || '2025/2026')}</div>
      <div class="statgrid">
        <div class="mini"><span>Mecze</span><b>${matches}</b></div>
        <div class="mini"><span>Gole</span><b>${goals}</b></div>
        <div class="mini"><span>Asysty</span><b>${assists}</b></div>
        <div class="mini"><span>Minuty</span><b>${minutes}'</b></div>
      </div>
    </div>
    <div class="hero-card">
      <div class="eyebrow">PUNKTY UMIEJĘTNOŚCI</div>
      <p>Do wykorzystania: <strong>${S.skillPoints || 0}</strong></p>
    </div>
  `;
}

async function renderClub() {
  const cName = S.club?.name || 'Klub';
  const chem = S.teamChemistry ?? 70;
  $('screen-club').innerHTML = `
    <div class="hero-card">
      <div class="eyebrow">${esc(S.club?.league || 'Liga')}</div>
      <div class="badge-row">
        <div class="crest">${initials(cName)}</div>
        <div class="score-block">
          <div class="score">#${S.club?.position || 1}</div>
          <div class="sub">Miejsce w lidze</div>
        </div>
      </div>
      <h2 style="text-align:center; margin-top:6px;">${esc(cName)}</h2>
      <div class="stat-row">
        <div class="labels"><span class="lbl">Chemia zespołu</span><span class="val">${chem}%</span></div>
        <div class="track"><div class="home" style="width:${chem}%"></div></div>
      </div>
    </div>
  `;
}

/* WIDOK ŚWIATA I TUK PRZEŁĄCZNIK LIG */
async function renderWorld() {
  const leagues = Object.keys(LEAGUES_DATA);

  let tabsHtml = `<div style="display:flex; gap:6px; overflow-x:auto; padding-bottom:10px; margin-bottom:10px;">`;
  leagues.forEach(l => {
    const active = l === currentWorldLeague;
    tabsHtml += `
      <button class="ghost" style="padding:6px 12px; font-size:0.75rem; border-radius:20px; flex-shrink:0; width:auto; ${active ? 'background:var(--grad-main); color:#fff; border:none;' : ''}" onclick="window.switchWorldLeague('${l}')">
        ${l}
      </button>
    `;
  });
  tabsHtml += `</div>`;

  let standings = (currentWorldLeague === S.club?.league && S.standings) 
    ? S.standings 
    : LEAGUES_DATA[currentWorldLeague].map((team, idx) => ({ pos: idx + 1, name: team, pts: Math.max(0, 30 - idx * 2) }));

  const maxPts = Math.max(...standings.map(t => t.pts), 1);

  $('screen-world').innerHTML = `
    <div class="topbar"><h2>Tabela ligowa</h2></div>
    ${tabsHtml}
    <div class="hero-card">
      <div class="eyebrow">${esc(currentWorldLeague)}</div>
      <div style="max-height: 55vh; overflow-y: auto; padding-right: 4px;">
        ${standings.map(t => {
          const isMyClub = t.name === S?.club?.name;
          return `
            <div class="stat-row" style="margin-bottom: 10px;">
              <div class="labels">
                <span class="lbl" style="color: ${isMyClub ? 'var(--accent-neon)' : 'inherit'}; font-weight: ${isMyClub ? '900' : '700'};">
                  ${t.pos}. ${esc(t.name)} ${isMyClub ? '⭐' : ''}
                </span>
                <span class="val">${t.pts} pkt</span>
              </div>
              <div class="track">
                <div class="${isMyClub ? 'home' : 'away'}" style="width: ${Math.min(100, Math.max(5, (t.pts / maxPts) * 100))}%"></div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;
}

window.switchWorldLeague = function(leagueName) {
  currentWorldLeague = leagueName;
  renderWorld();
};

function renderCups() {
  $('screen-cups').innerHTML = `
    <div class="topbar"><h2>Gablota trofeów</h2></div>
    <div class="hero-card"><p class="muted">Brak nowych trofeów — zdobądź pierwszy puchar w tym sezonie.</p></div>
  `;
}

function renderNational() {
  $('screen-national').innerHTML = `
    <div class="topbar"><h2>Reprezentacja</h2></div>
    <div class="hero-card"><p class="muted">Powołania wkrótce — utrzymuj wysoką formę klubową.</p></div>
  `;
}

function renderProfile() {
  $('screen-profile').innerHTML = `
    <div class="hero-card">
      <div class="badge-row"><div class="crest">${initials(S.player?.name)}</div></div>
      <h2 style="text-align:center;">${esc(S.player?.name)}</h2>
      <p style="text-align:center;">${esc(S.club?.name || '')}</p>
    </div>
    <div class="hero-card">
      <button class="primary" onclick="saveGame()">💾 ZAPISZ GRĘ LOKALNIE</button>
      <button class="ghost" style="margin-top:8px;" onclick="window.openSettingsFromGame()">⚙️ USTAWIENIA</button>
      <button class="ghost" style="margin-top:8px;" onclick="window.backToMainMenu()">🏠 MENU GŁÓWNE</button>
    </div>
  `;
}

function updateCustomUI(state) {}

let settingsReturnTo = 'mainmenu';
const DISCORD_INVITE_URL = ''; 

window.openSettingsFromGame = function() {
  settingsReturnTo = 'game';
  showPanel('settings');
};

window.backToMainMenu = function() {
  showPanel('mainmenu');
};

document.addEventListener('DOMContentLoaded', () => {
  const splash = $('splash');
  
  const dismissSplash = () => {
    if (splash && splash.style.display !== 'none') {
      splash.classList.add('fade-out');
      setTimeout(() => {
        splash.style.display = 'none';
        splash.classList.remove('show');
        showPanel('mainmenu');
      }, 400);
    } else {
      showPanel('mainmenu');
    }
  };

  setTimeout(dismissSplash, 1800);

  document.querySelectorAll('#nav button').forEach(b => {
    b.onclick = () => nav(b.dataset.screen);
  });

  $('menuNewGame')?.addEventListener('click', () => showPanel('onboarding'));

  $('menuLoadGame')?.addEventListener('click', () => {
    const raw = localStorage.getItem('fps_offline_db') || localStorage.getItem('fps_slot1');
    if (!raw) return toast('Brak zapisu');
    try {
      S = JSON.parse(raw);
      if (S.club && S.club.league) {
        if (S.club.league.includes('2.')) currentWorldLeague = '2. Liga';
        else if (S.club.league.includes('1.')) currentWorldLeague = '1. Liga';
        else if (S.club.league.includes('Ekstraklasa')) currentWorldLeague = 'Ekstraklasa';
        else currentWorldLeague = '3. Liga';
      }
      openGame();
      toast('Wczytano zapis');
    } catch (e) {
      toast('Uszkodzony zapis');
    }
  });

  $('menuSettings')?.addEventListener('click', () => {
    settingsReturnTo = 'mainmenu';
    showPanel('settings');
  });

  $('menuQuit')?.addEventListener('click', () => {
    try {
      if (window.Capacitor?.Plugins?.App?.exitApp) {
        window.Capacitor.Plugins.App.exitApp();
        return;
      }
    } catch (e) {}
    toast('Zamknij aplikację przyciskiem systemowym telefonu');
  });

  $('menuDiscord')?.addEventListener('click', () => {
    if (DISCORD_INVITE_URL) {
      window.open(DISCORD_INVITE_URL, '_blank');
    } else {
      toast('Serwer Discord wkrótce!');
    }
  });

  $('onboardingBack')?.addEventListener('click', () => showPanel('mainmenu'));
  $('settingsBack')?.addEventListener('click', () => showPanel(settingsReturnTo));

  const $anim = $('toggleAnimations');
  if ($anim) {
    $anim.checked = uiSettings.animations;
    $anim.addEventListener('change', () => {
      uiSettings.animations = $anim.checked;
      applySettings();
      saveSettings();
    });
  }

  const $light = $('toggleLightMode');
  if ($light) {
    $light.checked = uiSettings.theme === 'light';
    $light.addEventListener('change', () => {
      uiSettings.theme = $light.checked ? 'light' : 'dark';
      applySettings();
      saveSettings();
    });
  }

  const $sound = $('toggleSound');
  if ($sound) {
    $sound.checked = uiSettings.sound;
    $sound.addEventListener('change', () => {
      uiSettings.sound = $sound.checked;
      saveSettings();
    });
  }

  const $music = $('toggleMusic');
  if ($music) {
    $music.checked = uiSettings.music;
    $music.addEventListener('change', () => {
      uiSettings.music = $music.checked;
      saveSettings();
      if (uiSettings.music) playMusic(currentMusicKey || 'menu'); else stopMusic();
    });
  }

  const $vol = $('volumeSlider');
  if ($vol) {
    $vol.value = Math.round((uiSettings.volume ?? 0.7) * 100);
    $vol.addEventListener('input', () => {
      uiSettings.volume = Number($vol.value) / 100;
      saveSettings();
      applyMusicVolume();
    });
  }

  $('clearSaves')?.addEventListener('click', () => {
    localStorage.removeItem('fps_offline_db');
    localStorage.removeItem('fps_slot1');
    toast('Zapis lokalny usunięty');
  });
});
