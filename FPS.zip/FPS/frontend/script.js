Window.addEventListener('error', e => { 
  console.error(e.error || e.message); 
});

const SETTINGS_KEY = 'fps_ui_settings';

function loadSettings() {
  const defaults = { animations: true, sound: true, music: true, volume: 0.7, theme: 'dark' };
  try {
    return { ...defaults, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') };
  } catch (e) {
    return defaults;
  }
}

let uiSettings = loadSettings();

function applySettings() {
  document.documentElement.setAttribute('data-theme', uiSettings.theme);
  document.body.classList.toggle('no-animations', !uiSettings.animations);
}

function saveSettings() {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(uiSettings)); } catch (e) {}
}

applySettings();

let S = null;
let league = 'Ekstraklasa';
let toastTimer = null;

const $ = id => document.getElementById(id);

const esc = x => String(x ?? '').replace(/[&<>"']/g, m => ({ 
  '&': '&amp;', 
  '<': '&lt;', 
  '>': '&gt;', 
  '"': '&quot;', 
  "'": '&#39;' 
}[m]));

function toast(t) {
  const el = $('toast');
  if (!el) return;
  if (toastTimer) clearTimeout(toastTimer);
  
  el.textContent = t;
  el.classList.remove('show');
  void el.offsetWidth;
  el.classList.add('show');
  toastTimer = setTimeout(() => el.classList.remove('show'), 2400);
}

function vib(pattern = 18) {
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function' && !/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
      navigator.vibrate(pattern);
    }
  } catch (e) {}
}

const SFX_FILES = {
  click:   'audio/sfx_click.mp3',   
  whistle: 'audio/sfx_whistle.mp3', 
  goal:    'audio/sfx_goal.mp3',    
  perk:    'audio/sfx_perk.mp3',    
  trophy:  'audio/sfx_trophy.mp3',  
};

const MUSIC_FILES = {
  menu: 'audio/menu_music.mp3',   
  game: 'audio/game_ambient.mp3', 
};

const sfxCache = {};
function playSfx(name) {
  if (!uiSettings.sound) return;
  const src = SFX_FILES[name];
  if (!src) return;
  try {
    const base = sfxCache[name] || (sfxCache[name] = new Audio(src));
    const el = base.cloneNode();
    el.volume = uiSettings.volume ?? 0.7;
    el.play().catch(() => {});
  } catch (e) {}
}

const musicEls = {
  menu: null,
  game: null,
};
let currentMusicKey = null;

function getMusicEl(key) {
  if (!musicEls[key]) {
    const el = new Audio(MUSIC_FILES[key]);
    el.loop = true;
    musicEls[key] = el;
  }
  return musicEls[key];
}

function applyMusicVolume() {
  const vol = (uiSettings.volume ?? 0.7) * 0.5;
  Object.values(musicEls).forEach(el => { if (el) el.volume = vol; });
}

function playMusic(key) {
  if (!uiSettings.music) { stopMusic(); currentMusicKey = key; return; }
  if (currentMusicKey === key && musicEls[key] && !musicEls[key].paused) return;

  Object.entries(musicEls).forEach(([k, el]) => { if (el && k !== key) el.pause(); });

  const el = getMusicEl(key);
  applyMusicVolume();
  el.play().catch(() => {});
  currentMusicKey = key;
}

function stopMusic() {
  Object.values(musicEls).forEach(el => { if (el) el.pause(); });
}

function updateMusicForPanel(id) {
  if (id === 'game') {
    playMusic('game');
  } else {
    playMusic('menu');
  }
}

let musicArmed = false;
function armMusicOnFirstGesture() {
  if (musicArmed) return;
  musicArmed = true;
  if (uiSettings.music) {
    playMusic(currentMusicKey || 'menu');
  }
}

document.addEventListener('click', (e) => {
  armMusicOnFirstGesture();
  if (e.target.tagName === 'BUTTON' || e.target.closest('button')) {
    playSfx('click');
  }
});

document.addEventListener('pointerdown', (e) => {
  const btn = e.target.closest('button');
  if (!btn || btn.closest('#nav')) return;
  const rect = btn.getBoundingClientRect();
  const ripple = document.createElement('span');
  const size = Math.max(rect.width, rect.height) * 1.4;
  ripple.className = 'ripple';
  ripple.style.width = ripple.style.height = `${size}px`;
  ripple.style.left = `${(e.clientX ?? rect.left + rect.width / 2) - rect.left - size / 2}px`;
  ripple.style.top = `${(e.clientY ?? rect.top + rect.height / 2) - rect.top - size / 2}px`;
  btn.appendChild(ripple);
  ripple.addEventListener('animationend', () => ripple.remove(), { once: true });
});

const NAV_ORDER = ['home', 'career', 'club', 'world', 'cups', 'national', 'profile'];
let currentScreenName = 'home';

function showPanel(id) {
  document.querySelectorAll('.panel-screen').forEach(el => {
    el.classList.remove('show', 'active');
    el.classList.add('hidden');
    el.style.display = 'none';
  });
  
  const el = $(id);
  if (el) {
    el.classList.remove('hidden');
    el.classList.add('show', 'active');
    el.style.display = 'block';
  }
  updateMusicForPanel(id);
}

function openGame() {
  closeModal(true);
  showPanel('game');
  currentScreenName = 'home';
  renderAll();
}

function showModal(html) {
  const m = $('modal');
  const mc = $('modalContent');
  if (mc) mc.innerHTML = html;
  if (m) {
    m.classList.remove('hidden', 'closing');
    m.style.display = 'flex';
  }
}

window.closeModal = function(instant = false) {
  const m = $('modal');
  if (!m || m.classList.contains('hidden')) return;
  
  if (instant) {
    m.classList.add('hidden');
    m.classList.remove('closing');
    m.style.display = 'none';
    const mc = $('modalContent');
    if (mc) mc.innerHTML = '';
    return;
  }

  m.classList.add('closing');
  m.addEventListener('animationend', function handler() {
    m.classList.add('hidden');
    m.classList.remove('closing');
    m.style.display = 'none';
    const mc = $('modalContent');
    if (mc) mc.innerHTML = '';
    m.removeEventListener('animationend', handler);
  }, { once: true });
};

function nav(name) {
  if (name === currentScreenName) return;
  const newEl = $(`screen-${name}`);
  if (!newEl) return;
  const oldEl = document.querySelector('.screen.active');

  const oldIndex = NAV_ORDER.indexOf(currentScreenName);
  const newIndex = NAV_ORDER.indexOf(name);
  const dir = newIndex > oldIndex ? 'next' : 'prev';

  document.querySelectorAll('#nav button').forEach(b => {
    b.classList.toggle('active', b.dataset.screen === name);
  });

  renderScreen(name);

  if (oldEl && oldEl !== newEl) {
    oldEl.classList.remove('active');
  }

  newEl.classList.remove('enter-next', 'enter-prev');
  newEl.classList.add('active', dir === 'next' ? 'enter-next' : 'enter-prev');
  newEl.addEventListener('animationend', function handler() {
    newEl.classList.remove('enter-next', 'enter-prev');
    newEl.removeEventListener('animationend', handler);
  }, { once: true });

  currentScreenName = name;
  vib(10);
}

window.startCareer = async function(event) {
  if (event) event.preventDefault();

  const payload = {
    firstName: $('firstName')?.value.trim() || 'Mateusz',
    lastName: $('lastName')?.value.trim() || 'Kowalski',
    position: $('position')?.value || 'ST',
    age: Number($('age')?.value || 18)
  };

  if (!payload.firstName || !payload.lastName) {
    return toast('Wpisz imię i nazwisko');
  }
  
  try {
    const response = await window.api('/career/create', { 
      method: 'POST', 
      body: JSON.stringify(payload) 
    });
    S = response.state || response;
    
    // Zawsze otwieramy oferty (zostaną wygenerowane polskie niższe ligi)
    openOffers(S.offers);
  } catch (err) {
    toast(err.message || 'Błąd tworzenia kariery');
  }
};

/* Generowanie ofert z polskich niższych lig (1x 3.Liga, 2x 2.Liga, 1x 1.Liga) */
function openOffers(rawOffers) {
  const initialPolishOffers = [
    { clubId: 'c3_1', club: 'MKS Kluczbork', league: '3. Liga (Gr. 3)', wage: 800 },
    { clubId: 'c2_1', club: 'KKS 1925 Kalisz', league: '2. Liga Polska', wage: 1500 },
    { clubId: 'c2_2', club: 'Olimpia Elbląg', league: '2. Liga Polska', wage: 1700 },
    { clubId: 'c1_1', club: 'Polonia Warszawa', league: '1. Liga Polska', wage: 2800 }
  ];

  const offers = (rawOffers && rawOffers.length >= 4) ? rawOffers : initialPolishOffers;

  const html = `
    <div class="eyebrow">PIERWSZY KONTRAKT</div>
    <h2 style="color:#fff; margin-bottom:8px;">Wybierz swój pierwszy klub</h2>
    <p class="muted" style="margin-bottom:16px;">Zacznij karierę w niższych ligach i przebij się na szczyt.</p>
    <div style="max-height: 50vh; overflow-y: auto; padding-right: 4px;">
      ${offers.map((o, idx) => {
        return `
          <button class="ghost offer-btn" data-index="${idx}" style="width:100%; margin-bottom:8px; text-align:left; border-radius:12px;">
            <b>${esc(o.club)}</b><br>
            <span style="font-size:0.75rem; color:var(--text-muted);">
              ${o.league ? esc(o.league) + ' • ' : ''} Oferowana pensja: ${o.wage ? Number(o.wage).toLocaleString() : 0} PLN/tydz.
            </span>
          </button>
        `;
      }).join('')}
    </div>
  `;

  showModal(html);

  document.querySelectorAll('.offer-btn').forEach(b => {
    b.onclick = () => {
      const idx = Number(b.dataset.index);
      const o = offers[idx];
      const clubIdValue = o.clubId !== undefined ? o.clubId : (o.id !== undefined ? o.id : o.club);
      openNegotiationModal(clubIdValue, o.club, o.wage || 1000);
    };
  });
}

window.openNegotiationModal = function(clubId, clubName, baseWage, initialPatience = 100, alertMsg = '') {
  const html = `
    <div class="eyebrow">NEGOCJACJE KONTRAKTU</div>
    <h2 style="color:#fff; margin-bottom:4px;">${esc(clubName)}</h2>
    <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:12px;">
      Cierpliwość zarządu: <b style="color:${initialPatience > 50 ? 'var(--accent-green)' : '#ef4444'};">${initialPatience}%</b>
    </p>

    ${alertMsg ? `<div style="background:rgba(239, 68, 68, 0.15); border:1px solid #ef4444; color:#fff; padding:8px 12px; border-radius:8px; font-size:0.75rem; margin-bottom:12px;">${alertMsg}</div>` : ''}

    <div style="margin-bottom:10px;">
      <label style="font-size:0.75rem; color:var(--text-muted);">ŻĄDANA PENSJA TYGODNIOWA (PLN):</label>
      <input type="number" id="neg-wage" value="${baseWage}" style="width:100%; padding:10px; margin-top:4px; background:rgba(0,0,0,0.3); border:1px solid var(--border-color); color:#fff; border-radius:8px; font-weight:bold;">
    </div>

    <button id="btn-submit-contract" class="action primaryAction" style="width:100%; padding:12px; margin-top:4px;">
      📑 PRZEDSTAW WARUNKI
    </button>
    <button class="action" style="width:100%; margin-top:6px;" onclick="closeModal()">ANULUJ</button>
  `;

  showModal(html);

  const btn = $('btn-submit-contract');
  if (btn) {
    btn.onclick = () => {
      window.submitContractOffer(clubId, clubName, initialPatience);
    };
  }
};

window.submitContractOffer = async function(clubId, clubName, patience) {
  const wage = Number($('neg-wage')?.value || 0);

  try {
    const res = await window.api('/contract/negotiate', { 
      method: 'POST', 
      body: JSON.stringify({ clubId, wage, patience }) 
    });

    closeModal(true);
    playSfx('trophy');
    vib([30, 50, 30]);
    toast(res.message || 'Podpisano kontrakt!');
    if (res.state) S = res.state;
    openGame();
  } catch (e) {
    // Jeśli API offline - ręczne ustawienie klubu
    if (S) {
      S.club = { name: clubName, league: 'Polska Liga', position: 1 };
      S.finances = { balance: wage * 4 };
    }
    closeModal(true);
    playSfx('trophy');
    toast(`Podpisano kontrakt z ${clubName}!`);
    openGame();
  }
};

async function saveGame() {
  try {
    const snap = await window.api('/save');
    const dataStr = JSON.stringify(snap || S);
    localStorage.setItem('fps_offline_db', dataStr);
    localStorage.setItem('fps_slot1', dataStr);
    toast('Zapisano karierę');
    vib(20);
  } catch (e) { 
    if (S) {
      localStorage.setItem('fps_offline_db', JSON.stringify(S));
      localStorage.setItem('fps_slot1', JSON.stringify(S));
      toast('Zapisano karierę lokalnie');
    }
  }
}

function updateStateAndUI(newState) {
  S = newState;
  renderAll();
}

function renderAll() {
  if (!S) return;
  
  if (S.calendar && S.club) {
    const sLabel = $('seasonLabel');
    const cLabel = $('clubLabel');
    if (sLabel) sLabel.textContent = `${S.calendar.season} • KOLEJKA ${S.calendar.matchday}/${S.calendar.totalMatchdays || 30}`;
    if (cLabel) cLabel.textContent = S.club.name || '—';
  }
  
  const activeScreen = document.querySelector('.screen.active');
  if (activeScreen) {
    renderScreen(activeScreen.id.replace('screen-', ''));
  }
  updateCustomUI(S);
}

window.renderAll = renderAll;

function renderScreen(name) {
  if (!S) return;
  ({
    home: renderHome, 
    career: renderCareer, 
    club: renderClub,
    world: renderWorld, 
    cups: renderCups, 
    national: renderNational, 
    profile: renderProfile
  }[name] || renderHome)();
}

function initials(name) {
  return String(name || '?').split(' ').filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

function renderHome() {
  const f = S.fixture;
  const trust = S.relationships?.managerTrust ?? 50;
  const condition = S.player?.condition ?? 100;

  $('screen-home').innerHTML = `
    <div class="hero-card">
      <div class="eyebrow">${esc(S.club?.league || 'Liga')} • ${S.club?.position || 1}. MIEJSCE</div>
      <div class="matchline">
        <div>
          <div class="name">${esc(S.player?.name || 'Gracz')}</div>
          <p>${S.player?.age || 18} lat • ${esc(S.player?.position || 'ST')} • #${S.player?.number || 10}</p>
        </div>
        <div class="ovr">${S.player?.ovr || 60}<small>OVR</small></div>
      </div>
      <div class="stat-row">
        <div class="labels"><span class="lbl">Dyspozycja</span><span class="val">${condition}%</span></div>
        <div class="track"><div class="home" style="width:${condition}%"></div></div>
      </div>
    </div>

    <div class="hero-card match-card">
      <div class="eyebrow live"><span class="dot"></span>NASTĘPNY MECZ</div>
      <div class="badge-row">
        <div class="crest">${initials(f?.home || S.club?.name)}</div>
        <div class="score-block">
          <div class="score">VS</div>
          <div class="sub">${esc(S.calendar?.season || '2025/2026')}</div>
        </div>
        <div class="crest">${initials(f?.away || 'Przeciwnik')}</div>
      </div>
      <div class="team-names"><b>${esc(f?.home || S.club?.name || '—')}</b><span>KOLEJKA ${S.calendar?.matchday || 1}</span><b>${esc(f?.away || 'Rywal')}</b></div>
      <button class="primary" style="margin-top:16px;" onclick="window.simulate()">▶ ROZEGRAJ MECZ</button>
      <button class="ghost" style="margin-top:8px;" onclick="window.trainingModal()">🏋️ TRENING</button>
    </div>

    <div class="hero-card">
      <div class="eyebrow">STATUS KLUBOWY</div>
      <div class="statgrid">
        <div class="mini">
          <span>Portfel</span>
          <b>${(S.finances?.balance || 0).toLocaleString()} PLN</b>
        </div>
        <div class="mini">
          <span>Zaufanie trenera</span>
          <b>${trust}/100</b>
          <div class="meter"><span style="width:${trust}%"></span></div>
        </div>
      </div>
    </div>
  `;
}

window.simulate = async function() {
  playSfx('whistle');
  try {
    const d = await window.api('/match/simulate', { method: 'POST' });
    S = d.state || d;
    playSfx('goal');
    vib([30, 50, 30]);
    toast(`Mecz rozegrany!`);
    renderAll();
  } catch (e) { 
    if (S) {
      if (!S.calendar) S.calendar = { matchday: 1 };
      S.calendar.matchday += 1;
      if (!S.stats) S.stats = { matches: 0, goals: 0 };
      S.stats.matches += 1;
    }
    playSfx('goal');
    vib([30, 50, 30]);
    toast(`Mecz rozegrany!`);
    renderAll();
  }
};

window.trainingModal = async function() {
  try {
    S = await window.api('/training', { method: 'POST' });
    playSfx('perk');
    toast('Trening zaliczony! OVR +1');
    vib(18);
    renderAll();
  } catch (e) {
    if (S && S.player) S.player.ovr = (S.player.ovr || 60) + 1;
    playSfx('perk');
    toast('Trening zaliczony! OVR +1');
    vib(18);
    renderAll();
  }
};

function renderCareer() {
  const matches = S.stats?.matches || 0;
  const goals = S.stats?.goals || 0;
  const assists = S.stats?.assists || 0;
  const minutes = S.stats?.minutes || 0;
  $('screen-career').innerHTML = `
    <div class="topbar"><h2>Twoja kariera</h2></div>
    <div class="hero-card">
      <div class="eyebrow">SEZON ${esc(S.calendar?.season || '2025/2026')}</div>
      <div class="statgrid">
        <div class="mini"><span>Mecze</span><b>${matches}</b></div>
        <div class="mini"><span>Gole</span><b>${goals}</b></div>
        <div class="mini"><span>Asysty</span><b>${assists}</b></div>
        <div class="mini"><span>Minuty</span><b>${minutes}'</b></div>
      </div>
    </div>
    <div class="hero-card">
      <div class="eyebrow">PUNKTY UMIEJĘTNOŚCI</div>
      <p>Do wykorzystania: <strong>${S.skillPoints || 0}</strong></p>
    </div>
  `;
}

async function renderClub() {
  const cName = S.club?.name || 'Klub';
  const chem = S.teamChemistry ?? 70;
  $('screen-club').innerHTML = `
    <div class="hero-card">
      <div class="eyebrow">${esc(S.club?.league || 'Liga')}</div>
      <div class="badge-row">
        <div class="crest">${initials(cName)}</div>
        <div class="score-block">
          <div class="score">#${S.club?.position || 1}</div>
          <div class="sub">Miejsce w lidze</div>
        </div>
      </div>
      <h2 style="text-align:center; margin-top:6px;">${esc(cName)}</h2>
      <div class="stat-row">
        <div class="labels"><span class="lbl">Chemia zespołu</span><span class="val">${chem}%</span></div>
        <div class="track"><div class="home" style="width:${chem}%"></div></div>
      </div>
    </div>
  `;
}

/* RENDEROAWNIE PEŁNEJ TABELI LIGOWEJ */
async function renderWorld() {
  const matchday = S.calendar?.matchday || 1;
  
  // Jeśli backend nie podał tabeli, generujemy pełną 18-zespołową ligę
  const standings = S?.standings || [
    { pos: 1, name: S?.club?.name || 'Legia Warszawa', pts: matchday * 3 },
    { pos: 2, name: 'Lech Poznań', pts: Math.max(0, matchday * 3 - 2) },
    { pos: 3, name: 'Raków Częstochowa', pts: Math.max(0, matchday * 3 - 4) },
    { pos: 4, name: 'Pogoń Szczecin', pts: Math.max(0, matchday * 3 - 5) },
    { pos: 5, name: 'Jagiellonia Białystok', pts: Math.max(0, matchday * 3 - 7) },
    { pos: 6, name: 'Śląsk Wrocław', pts: Math.max(0, matchday * 3 - 9) },
    { pos: 7, name: 'Górnik Zabrze', pts: Math.max(0, matchday * 3 - 11) },
    { pos: 8, name: 'Widzew Łódź', pts: Math.max(0, matchday * 3 - 12) },
    { pos: 9, name: 'Cracovia', pts: Math.max(0, matchday * 3 - 14) },
    { pos: 10, name: 'Piast Gliwice', pts: Math.max(0, matchday * 3 - 15) },
    { pos: 11, name: 'Zagłębie Lubin', pts: Math.max(0, matchday * 3 - 16) },
    { pos: 12, name: 'Warta Poznań', pts: Math.max(0, matchday * 3 - 18) },
    { pos: 13, name: 'Radomiak Radom', pts: Math.max(0, matchday * 3 - 19) },
    { pos: 14, name: 'Korona Kielce', pts: Math.max(0, matchday * 3 - 20) },
    { pos: 15, name: 'Stal Mielec', pts: Math.max(0, matchday * 3 - 21) },
    { pos: 16, name: 'Puszcza Niepołomice', pts: Math.max(0, matchday * 3 - 23) },
    { pos: 17, name: 'Ruch Chorzów', pts: Math.max(0, matchday * 3 - 25) },
    { pos: 18, name: 'ŁKS Łódź', pts: Math.max(0, matchday * 3 - 27) }
  ];

  const maxPts = Math.max(...standings.map(t => t.pts), 1);

  $('screen-world').innerHTML = `
    <div class="topbar"><h2>Tabela ligowa</h2></div>
    <div class="hero-card">
      <div class="eyebrow">${esc(S?.club?.league || 'Ekstraklasa')}</div>
      <div style="max-height: 60vh; overflow-y: auto; padding-right: 4px;">
        ${standings.map(t => {
          const isMyClub = t.name === S?.club?.name;
          return `
            <div class="stat-row" style="margin-bottom: 10px;">
              <div class="labels">
                <span class="lbl" style="color: ${isMyClub ? 'var(--accent-neon)' : 'inherit'}; font-weight: ${isMyClub ? '900' : '700'};">
                  ${t.pos}. ${esc(t.name)} ${isMyClub ? '⭐' : ''}
                </span>
                <span class="val">${t.pts} pkt</span>
              </div>
              <div class="track">
                <div class="${isMyClub ? 'home' : 'away'}" style="width: ${Math.min(100, Math.max(5, (t.pts / maxPts) * 100))}%"></div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;
}

function renderCups() {
  $('screen-cups').innerHTML = `
    <div class="topbar"><h2>Gablota trofeów</h2></div>
    <div class="hero-card"><p class="muted">Brak nowych trofeów — zdobądź pierwszy puchar w tym sezonie.</p></div>
  `;
}

function renderNational() {
  $('screen-national').innerHTML = `
    <div class="topbar"><h2>Reprezentacja</h2></div>
    <div class="hero-card"><p class="muted">Powołania wkrótce — utrzymuj wysoką formę klubową.</p></div>
  `;
}

function renderProfile() {
  $('screen-profile').innerHTML = `
    <div class="hero-card">
      <div class="badge-row"><div class="crest">${initials(S.player?.name)}</div></div>
      <h2 style="text-align:center;">${esc(S.player?.name)}</h2>
      <p style="text-align:center;">${esc(S.club?.name || '')}</p>
    </div>
    <div class="hero-card">
      <button class="primary" onclick="saveGame()">💾 ZAPISZ GRĘ LOKALNIE</button>
      <button class="ghost" style="margin-top:8px;" onclick="window.openSettingsFromGame()">⚙️ USTAWIENIA</button>
      <button class="ghost" style="margin-top:8px;" onclick="window.backToMainMenu()">🏠 MENU GŁÓWNE</button>
    </div>
  `;
}

function updateCustomUI(state) {}

let settingsReturnTo = 'mainmenu';
const DISCORD_INVITE_URL = ''; 

window.openSettingsFromGame = function() {
  settingsReturnTo = 'game';
  showPanel('settings');
};

window.backToMainMenu = function() {
  showPanel('mainmenu');
};

document.addEventListener('DOMContentLoaded', () => {
  const splash = $('splash');
  setTimeout(() => {
    if (splash) {
      splash.classList.add('fade-out');
      setTimeout(() => {
        splash.classList.remove('show');
        showPanel('mainmenu');
      }, 650);
    } else {
      showPanel('mainmenu');
    }
  }, 2200);

  document.querySelectorAll('#nav button').forEach(b => {
    b.onclick = () => nav(b.dataset.screen);
  });

  $('menuNewGame')?.addEventListener('click', () => showPanel('onboarding'));

  $('menuLoadGame')?.addEventListener('click', () => {
    const raw = localStorage.getItem('fps_offline_db') || localStorage.getItem('fps_slot1');
    if (!raw) return toast('Brak zapisu');
    try {
      S = JSON.parse(raw);
      openGame();
      toast('Wczytano zapis');
    } catch (e) {
      toast('Uszkodzony zapis');
    }
  });

  $('menuSettings')?.addEventListener('click', () => {
    settingsReturnTo = 'mainmenu';
    showPanel('settings');
  });

  $('menuQuit')?.addEventListener('click', () => {
    try {
      if (window.Capacitor?.Plugins?.App?.exitApp) {
        window.Capacitor.Plugins.App.exitApp();
        return;
      }
    } catch (e) {}
    toast('Zamknij aplikację przyciskiem systemowym telefonu');
  });

  $('menuDiscord')?.addEventListener('click', () => {
    if (DISCORD_INVITE_URL) {
      window.open(DISCORD_INVITE_URL, '_blank');
    } else {
      toast('Serwer Discord wkrótce!');
    }
  });

  $('onboardingBack')?.addEventListener('click', () => showPanel('mainmenu'));
  $('settingsBack')?.addEventListener('click', () => showPanel(settingsReturnTo));

  const $anim = $('toggleAnimations');
  if ($anim) {
    $anim.checked = uiSettings.animations;
    $anim.addEventListener('change', () => {
      uiSettings.animations = $anim.checked;
      applySettings();
      saveSettings();
    });
  }

  const $light = $('toggleLightMode');
  if ($light) {
    $light.checked = uiSettings.theme === 'light';
    $light.addEventListener('change', () => {
      uiSettings.theme = $light.checked ? 'light' : 'dark';
      applySettings();
      saveSettings();
    });
  }

  const $sound = $('toggleSound');
  if ($sound) {
    $sound.checked = uiSettings.sound;
    $sound.addEventListener('change', () => {
      uiSettings.sound = $sound.checked;
      saveSettings();
    });
  }

  const $music = $('toggleMusic');
  if ($music) {
    $music.checked = uiSettings.music;
    $music.addEventListener('change', () => {
      uiSettings.music = $music.checked;
      saveSettings();
      if (uiSettings.music) playMusic(currentMusicKey || 'menu'); else stopMusic();
    });
  }

  const $vol = $('volumeSlider');
  if ($vol) {
    $vol.value = Math.round((uiSettings.volume ?? 0.7) * 100);
    $vol.addEventListener('input', () => {
      uiSettings.volume = Number($vol.value) / 100;
      saveSettings();
      applyMusicVolume();
    });
  }

  $('clearSaves')?.addEventListener('click', () => {
    localStorage.removeItem('fps_offline_db');
    localStorage.removeItem('fps_slot1');
    toast('Zapis lokalny usunięty');
  });
});
