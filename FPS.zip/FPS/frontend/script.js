window.addEventListener('error', e => { 
  console.error(e.error || e.message); 
});

const SETTINGS_KEY = 'fps_ui_settings';
let currentWorldLeague = 'Ekstraklasa';

// PEŁNA BAZA POLSKICH LIG I KLUBÓW
const LEAGUES_DATA = {
  'Ekstraklasa': ['Legia Warszawa', 'Lech Poznań', 'Raków Częstochowa', 'Pogoń Szczecin', 'Jagiellonia Białystok', 'Śląsk Wrocław', 'Górnik Zabrze', 'Widzew Łódź', 'Cracovia', 'Piast Gliwice', 'Zagłębie Lubin', 'Warta Poznań', 'Radomiak Radom', 'Korona Kielce', 'Stal Mielec', 'Puszcza Niepołomice', 'Ruch Chorzów', 'ŁKS Łódź'],
  '1. Liga': ['Wisła Kraków', 'Lechia Gdańsk', 'Arka Gdynia', 'Motor Lublin', 'GKS Katowice', 'Odra Opole', 'Górnik Łęczna', 'Miedź Legnica', 'Polonia Warszawa', 'Znicz Pruszków', 'Resovia Rzeszów', 'Podbeskidzie', 'Chrobry Głogów', 'Stal Rzeszów', 'GKS Tychy', 'Bruk-Bet Termalica', 'Wisła Płock', 'Zagłębie Sosnowiec'],
  '2. Liga': ['KKS 1925 Kalisz', 'Kotwica Kołobrzeg', 'Radunia Stężyca', 'Hutnik Kraków', 'Chojniczanka', 'Olimpia Elbląg', 'Stal Stalowa Wola', 'ŁKS II Łódź', 'Polonia Bytom', 'GKS Jastrzębie', 'Olimpia Grudziądz', 'Sandecja Nowy Sącz', 'Zagłębie II Lubin', 'Wisła Puławy', 'Pogoń Siedlce', 'Stomil Olsztyn', 'Skra Częstochowa', 'Lech II Poznań'],
  '3. Liga (Gr. 1)': ['Pogoń Grodzisk Maz.', 'Legia II Warszawa', 'Pelikan Łowicz', 'Świt Nowy Dwór Maz.', 'GKS Wikielec', 'Unia Skierniewice', 'Broń Radom', 'Victoria Sulejówek'],
  '3. Liga (Gr. 2)': ['Elana Toruń', 'Świt Szczecin', 'Zawisza Bydgoszcz', 'Unia Swarzędz', 'Vineta Wolin', 'Pogoń Nowe Skalmierzyce', 'Sokół Kleczew', 'Gedania Gdańsk'],
  '3. Liga (Gr. 3)': ['MKS Kluczbork', 'Rekord Bielsko-Biała', 'Śląsk II Wrocław', 'Goczałkowice Zdrój', 'Carina Gubin', 'Star Starachowice', 'Stal Brzeg', 'Górnik II Zabrze'],
  '3. Liga (Gr. 4)': ['Wieczysta Kraków', 'Avia Świdnik', 'Siarka Tarnobrzeg', 'KSZO Ostrowiec', 'Chełmianka Chełm', 'Podhale Nowy Targ', 'Wisłoka Dębica', 'Garbarnia Kraków']
};

function loadSettings() {
  const defaults = { animations: true, sound: true, music: true, volume: 0.7, theme: 'dark' };
  try {
    return { ...defaults, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') };
  } catch (e) {
    return defaults;
  }
}

let uiSettings = loadSettings();

function applySettings() {
  document.documentElement.setAttribute('data-theme', uiSettings.theme);
  document.body.classList.toggle('no-animations', !uiSettings.animations);
}

function saveSettings() {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(uiSettings)); } catch (e) {}
}

applySettings();

let S = null;
let toastTimer = null;

const $ = id => document.getElementById(id);

const esc = x => String(x ?? '').replace(/[&<>"']/g, m => ({ 
  '&': '&amp;', 
  '<': '&lt;', 
  '>': '&gt;', 
  '"': '&quot;', 
  "'": '&#39;' 
}[m]));

function toast(t) {
  const el = $('toast');
  if (!el) return;
  if (toastTimer) clearTimeout(toastTimer);
  
  el.textContent = t;
  el.classList.remove('show');
  void el.offsetWidth;
  el.classList.add('show');
  toastTimer = setTimeout(() => el.classList.remove('show'), 2400);
}

function vib(pattern = 18) {
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function' && !/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
      navigator.vibrate(pattern);
    }
  } catch (e) {}
}

const SFX_FILES = {
  click:   'audio/sfx_click.mp3',   
  whistle: 'audio/sfx_whistle.mp3', 
  goal:    'audio/sfx_goal.mp3',    
  perk:    'audio/sfx_perk.mp3',    
  trophy:  'audio/sfx_trophy.mp3',  
};

const MUSIC_FILES = {
  menu: 'audio/menu_music.mp3',   
  game: 'audio/game_ambient.mp3', 
};

const sfxCache = {};
function playSfx(name) {
  if (!uiSettings.sound) return;
  const src = SFX_FILES[name];
  if (!src) return;
  try {
    const base = sfxCache[name] || (sfxCache[name] = new Audio(src));
    const el = base.cloneNode();
    el.volume = uiSettings.volume ?? 0.7;
    el.play().catch(() => {});
  } catch (e) {}
}

const musicEls = { menu: null, game: null };
let currentMusicKey = null;

function getMusicEl(key) {
  if (!musicEls[key]) {
    const el = new Audio(MUSIC_FILES[key]);
    el.loop = true;
    musicEls[key] = el;
  }
  return musicEls[key];
}

function applyMusicVolume() {
  const vol = (uiSettings.volume ?? 0.7) * 0.5;
  Object.values(musicEls).forEach(el => { if (el) el.volume = vol; });
}

function playMusic(key) {
  if (!uiSettings.music) { stopMusic(); currentMusicKey = key; return; }
  if (currentMusicKey === key && musicEls[key] && !musicEls[key].paused) return;

  Object.entries(musicEls).forEach(([k, el]) => { if (el && k !== key) el.pause(); });

  const el = getMusicEl(key);
  applyMusicVolume();
  el.play().catch(() => {});
  currentMusicKey = key;
}

function stopMusic() {
  Object.values(musicEls).forEach(el => { if (el) el.pause(); });
}

function updateMusicForPanel(id) {
  if (id === 'game') {
    playMusic('game');
  } else {
    playMusic('menu');
  }
}

let musicArmed = false;
function armMusicOnFirstGesture() {
  if (musicArmed) return;
  musicArmed = true;
  if (uiSettings.music) {
    playMusic(currentMusicKey || 'menu');
  }
}

document.addEventListener('click', (e) => {
  armMusicOnFirstGesture();
  if (e.target.tagName === 'BUTTON' || e.target.closest('button')) {
    playSfx('click');
  }
});

let currentScreenName = 'home';

function showPanel(id) {
  document.querySelectorAll('.panel-screen').forEach(el => {
    if (el.id !== 'splash') {
      el.classList.remove('show', 'active');
      el.classList.add('hidden');
      el.style.display = 'none';
    }
  });
  
  const el = $(id);
  if (el) {
    el.classList.remove('hidden');
    el.classList.add('show', 'active');
    el.style.display = 'block';
  }
  updateMusicForPanel(id);
}

function openGame() {
  closeModal(true);
  showPanel('game');
  currentScreenName = 'home';
  renderAll();
}

function showModal(html) {
  const m = $('modal');
  const mc = $('modalContent');
  if (mc) mc.innerHTML = html;
  if (m) {
    m.classList.remove('hidden', 'closing');
    m.style.display = 'flex';
  }
}

window.closeModal = function(instant = false) {
  const m = $('modal');
  if (!m || m.classList.contains('hidden')) return;
  
  if (instant) {
    m.classList.add('hidden');
    m.classList.remove('closing');
    m.style.display = 'none';
    const mc = $('modalContent');
    if (mc) mc.innerHTML = '';
    return;
  }

  m.classList.add('closing');
  m.addEventListener('animationend', function handler() {
    m.classList.add('hidden');
    m.classList.remove('closing');
    m.style.display = 'none';
    const mc = $('modalContent');
    if (mc) mc.innerHTML = '';
    m.removeEventListener('animationend', handler);
  }, { once: true });
};

function nav(name) {
  currentScreenName = name;
  document.querySelectorAll('#nav button').forEach(b => {
    b.classList.toggle('active', b.dataset.screen === name);
  });

  document.querySelectorAll('.screen').forEach(s => {
    s.classList.remove('active');
  });

  const newEl = $(`screen-${name}`);
  if (newEl) {
    newEl.classList.add('active');
  }

  renderScreen(name);
  vib(10);
}

// GENEROWANIE CZYSTYCH TABEL DLA WSZYSTKICH LIG (0 PKT NA START)
function generateAllLeaguesState() {
  const state = {};
  Object.keys(LEAGUES_DATA).forEach(leagueName => {
    state[leagueName] = LEAGUES_DATA[leagueName].map((team, idx) => ({
      pos: idx + 1,
      name: team,
      played: 0,
      won: 0,
      drawn: 0,
      lost: 0,
      gf: 0,
      ga: 0,
      pts: 0
    }));
  });
  return state;
}

window.startCareer = async function(event) {
  if (event) event.preventDefault();

  const fName = $('firstName')?.value.trim() || 'Mateusz';
  const lName = $('lastName')?.value.trim() || 'Kowalski';
  const pos = $('position')?.value || 'ST';
  const age = Number($('age')?.value || 18);

  S = {
    player: {
      name: `${fName} ${lName}`,
      position: pos,
      age: age,
      ovr: 60,
      condition: 100,
      energy: 100,
      value: 50000
    },
    stats: { matches: 0, goals: 0, assists: 0, minutes: 0 },
    calendar: { season: '2025/2026', matchday: 1, totalMatchdays: 34 },
    relationships: { managerTrust: 60 },
    finances: { balance: 0, weeklyWage: 800 },
    club: { id: 'c3_3', name: 'MKS Kluczbork', league: '3. Liga (Gr. 3)', position: 1 },
    leagues: generateAllLeaguesState(),
    cup: { inCup: true, round: '1/32 Finału' }
  };

  openOffers();
};

function openOffers() {
  const offers = [
    { club: 'MKS Kluczbork', league: '3. Liga (Gr. 3)', wage: 800 },
    { club: 'KKS 1925 Kalisz', league: '2. Liga', wage: 1500 },
    { club: 'Polonia Warszawa', league: '1. Liga', wage: 2800 }
  ];

  const html = `
    <div class="eyebrow">PIERWSZY KONTRAKT</div>
    <h2 style="color:#fff; margin-bottom:8px;">Wybierz swój pierwszy klub</h2>
    <div style="max-height: 50vh; overflow-y: auto;">
      ${offers.map((o) => `
        <button class="ghost offer-btn" style="width:100%; margin-bottom:8px; text-align:left; border-radius:12px;" onclick="chooseClub('${o.club}', '${o.league}', ${o.wage})">
          <b>${esc(o.club)}</b><br>
          <span style="font-size:0.75rem; color:var(--text-muted);">${esc(o.league)} • Pensja: ${o.wage} PLN/tydz.</span>
        </button>
      `).join('')}
    </div>
  `;
  showModal(html);
}

window.chooseClub = function(clubName, leagueName, wage) {
  S.club = { name: clubName, league: leagueName, position: 1 };
  S.finances.weeklyWage = wage;
  S.finances.balance = wage * 4;
  currentWorldLeague = LEAGUES_DATA[leagueName] ? leagueName : '3. Liga (Gr. 3)';
  localStorage.setItem('fps_offline_db', JSON.stringify(S));
  closeModal(true);
  playSfx('trophy');
  openGame();
};

async function saveGame() {
  if (S) {
    const dataStr = JSON.stringify(S);
    localStorage.setItem('fps_offline_db', dataStr);
    localStorage.setItem('fps_slot1', dataStr);
    toast('Zapisano karierę lokalnie');
    vib(20);
  }
}

function renderAll() {
  if (!S) return;
  
  if (S.calendar && S.club) {
    const sLabel = $('seasonLabel');
    const cLabel = $('clubLabel');
    if (sLabel) sLabel.textContent = `${S.calendar.season} • KOLEJKA ${S.calendar.matchday}/${S.calendar.totalMatchdays || 34}`;
    if (cLabel) cLabel.textContent = S.club.name || '—';
  }
  
  renderScreen(currentScreenName);
}

window.renderAll = renderAll;

function renderScreen(name) {
  if (!S) return;
  ({
    home: renderHome, 
    career: renderCareer, 
    club: renderClub,
    world: renderWorld, 
    cups: renderCups, 
    national: renderNational, 
    profile: renderProfile
  }[name] || renderHome)();
}

function initials(name) {
  return String(name || '?').split(' ').filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

function renderHome() {
  const trust = S.relationships?.managerTrust ?? 60;
  const condition = S.player?.condition ?? 100;

  const leagueTeams = LEAGUES_DATA[S.club?.league] || LEAGUES_DATA['Ekstraklasa'];
  const opponent = leagueTeams.find(t => t !== S.club?.name) || 'Rywal';

  $('screen-home').innerHTML = `
    <div class="hero-card">
      <div class="eyebrow">${esc(S.club?.league || 'Liga')} • ${S.club?.position || 1}. MIEJSCE</div>
      <div class="matchline">
        <div>
          <div class="name">${esc(S.player?.name || 'Gracz')}</div>
          <p>${S.player?.age || 18} lat • ${esc(S.player?.position || 'ST')}</p>
        </div>
        <div class="ovr">${S.player?.ovr || 60}<small>OVR</small></div>
      </div>
      <div class="stat-row">
        <div class="labels"><span class="lbl">Forma fizyczna</span><span class="val">${condition}%</span></div>
        <div class="track"><div class="home" style="width:${condition}%"></div></div>
      </div>
    </div>

    <div class="hero-card match-card">
      <div class="eyebrow live"><span class="dot"></span>NASTĘPNY MECZ</div>
      <div class="badge-row">
        <div class="crest">${initials(S.club?.name)}</div>
        <div class="score-block">
          <div class="score">VS</div>
          <div class="sub">${esc(S.calendar?.season || '2025/2026')}</div>
        </div>
        <div class="crest">${initials(opponent)}</div>
      </div>
      <div class="team-names"><b>${esc(S.club?.name || '—')}</b><span>KOLEJKA ${S.calendar?.matchday || 1}</span><b>${esc(opponent)}</b></div>
      <button class="primary" style="margin-top:16px;" onclick="window.simulateMatch('${esc(opponent)}')">▶ ROZEGRAJ MECZ</button>
      <button class="ghost" style="margin-top:8px;" onclick="window.trainingModal()">🏋️ TRENING (+1 OVR)</button>
    </div>

    <div class="hero-card">
      <div class="eyebrow">STATUS KLUBOWY</div>
      <div class="statgrid">
        <div class="mini">
          <span>Konto</span>
          <b>${(S.finances?.balance || 0).toLocaleString()} PLN</b>
        </div>
        <div class="mini">
          <span>Zaufanie trenera</span>
          <b>${trust}/100</b>
          <div class="meter"><span style="width:${trust}%"></span></div>
        </div>
      </div>
    </div>
  `;
}

/* REALNY SILNIK MECZOWY Z ZMĘCZENIEM I SYMULACJĄ WSZYSTKICH DRUŻYN */
window.simulateMatch = function(opponent) {
  playSfx('whistle');
  
  let myGoals = 0;
  let oppGoals = 0;
  let playerGoals = 0;
  let playerAssists = 0;
  let logs = [];

  const effectiveRating = (S.player?.ovr || 60) * ((S.player?.condition || 100) / 100);
  const playerChance = (effectiveRating / 100) * 0.40;

  for (let min = 1; min <= 90; min += Math.floor(Math.random() * 14) + 1) {
    const rand = Math.random();
    if (rand < 0.08) {
      myGoals++;
      if (Math.random() < playerChance) {
        playerGoals++;
        logs.push(`<div class="log-item goal" style="color:var(--accent-neon); margin-bottom:4px;">⚽ <b>${min}' GOOOL!</b> Bramkę zdobywa <b>${esc(S.player?.name)}</b>!</div>`);
      } else if (Math.random() < 0.35) {
        playerAssists++;
        logs.push(`<div class="log-item goal" style="color:var(--accent-neon); margin-bottom:4px;">⚽ <b>${min}' GOL!</b> Trafienie dla ${esc(S.club?.name)} po asyście ${esc(S.player?.name)}!</div>`);
      } else {
        logs.push(`<div class="log-item" style="margin-bottom:4px;">⚽ <b>${min}' GOL!</b> Zespół ${esc(S.club?.name)} trafia do siatki!</div>`);
      }
    } else if (rand > 0.92) {
      oppGoals++;
      logs.push(`<div class="log-item" style="color:#ef4444; margin-bottom:4px;">⚽ <b>${min}' GOL!</b> ${esc(opponent)} zdobywa bramkę.</div>`);
    } else if (rand > 0.48 && rand < 0.50) {
      logs.push(`<div class="log-item" style="color:var(--text-muted); margin-bottom:4px;">🟨 <b>${min}'</b> Żółta karta po ostrej walce w środku pola.</div>`);
    }
  }

  // Zmęczenie po meczu (z logiki Python simulation.py)
  if (S.player) {
    S.player.condition = Math.max(40, (S.player.condition || 100) - Math.floor(Math.random() * 15 + 10));
  }

  if (!S.stats) S.stats = { matches: 0, goals: 0, assists: 0, minutes: 0 };
  S.stats.matches += 1;
  S.stats.goals += playerGoals;
  S.stats.assists += playerAssists;
  S.stats.minutes += 90;

  if (!S.calendar) S.calendar = { matchday: 1, totalMatchdays: 34 };
  S.calendar.matchday += 1;

  // Wypłata pensji tygodniowej co 4 mecze
  if (S.calendar.matchday % 4 === 0 && S.finances) {
    S.finances.balance += (S.finances.weeklyWage || 800) * 4;
  }

  if (!S.leagues) {
    S.leagues = generateAllLeaguesState();
  }

  // Symulacja wyników dla wszystkich lig w danej kolejce
  Object.keys(S.leagues).forEach(lName => {
    const table = S.leagues[lName];
    for (let i = 0; i < table.length - 1; i += 2) {
      const t1 = table[i];
      const t2 = table[i + 1];

      let g1, g2;
      if (t1.name === S.club?.name && t2.name === opponent) {
        g1 = myGoals; g2 = oppGoals;
      } else if (t2.name === S.club?.name && t1.name === opponent) {
        g1 = oppGoals; g2 = myGoals;
      } else {
        g1 = Math.floor(Math.random() * 3);
        g2 = Math.floor(Math.random() * 3);
      }

      t1.played += 1; t2.played += 1;
      t1.gf += g1; t1.ga += g2;
      t2.gf += g2; t2.ga += g1;

      if (g1 > g2) {
        t1.pts += 3; t1.won += 1; t2.lost += 1;
      } else if (g1 === g2) {
        t1.pts += 1; t2.pts += 1; t1.drawn += 1; t2.drawn += 1;
      } else {
        t2.pts += 3; t2.won += 1; t1.lost += 1;
      }
    }

    table.sort((a, b) => b.pts - a.pts || (b.gf - b.ga) - (a.gf - a.ga));
    table.forEach((t, i) => t.pos = i + 1);
  });

  const myLeagueTable = S.leagues[S.club?.league];
  if (myLeagueTable) {
    const myClubState = myLeagueTable.find(t => t.name === S.club?.name);
    if (myClubState && S.club) {
      S.club.position = myClubState.pos;
    }
  }

  localStorage.setItem('fps_offline_db', JSON.stringify(S));

  playSfx('goal');
  vib([30, 50, 30]);

  const html = `
    <div class="eyebrow">KONIEC MECZU</div>
    <h2 style="color:#fff; text-align:center; margin-bottom:12px;">${esc(S.club?.name)} ${myGoals} : ${oppGoals} ${esc(opponent)}</h2>
    <div style="background:rgba(255,255,255,0.05); padding:10px; border-radius:12px; text-align:center; margin-bottom:12px; font-size:0.85rem;">
      Wkład w mecz: <b>${playerGoals} Goli, ${playerAssists} Asyst</b>
    </div>
    <div style="max-height:180px; overflow-y:auto; background:rgba(0,0,0,0.3); padding:10px; border-radius:10px; font-size:0.75rem; border:1px solid var(--border-soft);">
      ${logs.length ? logs.join('') : '<div style="color:var(--text-muted);">Mecz przebiegł bez większych spięć pod bramkami.</div>'}
    </div>
    <button class="primary" style="margin-top:14px;" onclick="closeModal(true); renderAll();">KONTYNUUJ</button>
  `;

  showModal(html);
};

window.trainingModal = async function() {
  if (S && S.player) {
    S.player.ovr = (S.player.ovr || 60) + 1;
    S.player.condition = Math.min(100, (S.player.condition || 100) + 15);
    localStorage.setItem('fps_offline_db', JSON.stringify(S));
  }

  playSfx('perk');
  toast('Trening zaliczony! OVR +1, Kondycja +15%');
  vib(18);
  renderAll();
};

function renderCareer() {
  const matches = S.stats?.matches || 0;
  const goals = S.stats?.goals || 0;
  const assists = S.stats?.assists || 0;
  const minutes = S.stats?.minutes || 0;
  $('screen-career').innerHTML = `
    <div class="topbar"><h2>Twoja kariera</h2></div>
    <div class="hero-card">
      <div class="eyebrow">SEZON ${esc(S.calendar?.season || '2025/2026')}</div>
      <div class="statgrid">
        <div class="mini"><span>Mecze</span><b>${matches}</b></div>
        <div class="mini"><span>Gole</span><b>${goals}</b></div>
        <div class="mini"><span>Asysty</span><b>${assists}</b></div>
        <div class="mini"><span>Minuty</span><b>${minutes}'</b></div>
      </div>
    </div>
  `;
}

async function renderClub() {
  const cName = S.club?.name || 'Klub';
  const chem = S.teamChemistry ?? 70;
  $('screen-club').innerHTML = `
    <div class="hero-card">
      <div class="eyebrow">${esc(S.club?.league || 'Liga')}</div>
      <div class="badge-row">
        <div class="crest">${initials(cName)}</div>
        <div class="score-block">
          <div class="score">#${S.club?.position || 1}</div>
          <div class="sub">Miejsce w lidze</div>
        </div>
      </div>
      <h2 style="text-align:center; margin-top:6px;">${esc(cName)}</h2>
      <div class="stat-row">
        <div class="labels"><span class="lbl">Chemia zespołu</span><span class="val">${chem}%</span></div>
        <div class="track"><div class="home" style="width:${chem}%"></div></div>
      </div>
    </div>
  `;
}

/* WIDOK ŚWIATA Z PEŁNYMI I REALNYMI STATYSTYKAMI DRUŻYN */
async function renderWorld() {
  if (!S.leagues) {
    S.leagues = generateAllLeaguesState();
  }

  const leagues = Object.keys(S.leagues);

  let tabsHtml = `<div style="display:flex; gap:6px; overflow-x:auto; padding-bottom:10px; margin-bottom:10px;">`;
  leagues.forEach(l => {
    const active = l === currentWorldLeague;
    tabsHtml += `
      <button class="ghost" style="padding:6px 12px; font-size:0.75rem; border-radius:20px; flex-shrink:0; width:auto; ${active ? 'background:var(--grad-main); color:#fff; border:none;' : ''}" onclick="window.switchWorldLeague('${l}')">
        ${l}
      </button>
    `;
  });
  tabsHtml += `</div>`;

  let standings = S.leagues[currentWorldLeague] || [];

  $('screen-world').innerHTML = `
    <div class="topbar"><h2>Tabela ligowa</h2></div>
    ${tabsHtml}
    <div class="hero-card">
      <div class="eyebrow">${esc(currentWorldLeague)}</div>
      <div style="max-height: 55vh; overflow-y: auto; padding-right: 4px;">
        ${standings.map(t => {
          const isMyClub = t.name === S?.club?.name;
          return `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid rgba(255,255,255,0.06); ${isMyClub ? 'color:var(--accent-neon); font-weight:900;' : ''}">
              <span style="font-size:0.85rem;">
                ${t.pos}. <b>${esc(t.name)}</b> ${isMyClub ? '⭐' : ''}
              </span>
              <span style="font-size:0.8rem; font-weight:700;">
                ${t.pts} pkt <small style="color:var(--text-muted); font-weight:400;">(${t.played} M)</small>
              </span>
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;
}

window.switchWorldLeague = function(leagueName) {
  currentWorldLeague = leagueName;
  renderWorld();
};

function renderCups() {
  $('screen-cups').innerHTML = `
    <div class="topbar"><h2>Puchar Polski</h2></div>
    <div class="hero-card">
      <div class="eyebrow">ROZGRYWKI PUCHAROWE</div>
      <p>Status: <b>${S?.cup ? S.cup.round : '1/32 Finału'}</b></p>
    </div>
  `;
}

function renderNational() {
  $('screen-national').innerHTML = `
    <div class="topbar"><h2>Reprezentacja Polski</h2></div>
    <div class="hero-card"><p class="muted">Powołania zostaną otwarte po osiągnięciu min. 78 OVR.</p></div>
  `;
}

function renderProfile() {
  const val = (S?.player?.ovr || 60) * 12000;
  $('screen-profile').innerHTML = `
    <div class="hero-card">
      <div class="badge-row"><div class="crest">${initials(S?.player?.name)}</div></div>
      <h2 style="text-align:center;">${esc(S?.player?.name)}</h2>
      <p style="text-align:center; color:var(--text-muted); margin-bottom:12px;">Wartość rynkowa: ${val.toLocaleString()} PLN</p>
    </div>
    <div class="hero-card">
      <button class="primary" onclick="saveGame()">💾 ZAPISZ GRĘ LOKALNIE</button>
      <button class="ghost" style="margin-top:8px;" onclick="window.openSettingsFromGame()">⚙️ USTAWIENIA</button>
      <button class="ghost" style="margin-top:8px;" onclick="window.backToMainMenu()">🏠 MENU GŁÓWNE</button>
    </div>
  `;
}

function updateCustomUI(state) {}

let settingsReturnTo = 'mainmenu';
const DISCORD_INVITE_URL = ''; 

window.openSettingsFromGame = function() {
  settingsReturnTo = 'game';
  showPanel('settings');
};

window.backToMainMenu = function() {
  showPanel('mainmenu');
};

document.addEventListener('DOMContentLoaded', () => {
  const splash = $('splash');
  
  const dismissSplash = () => {
    if (splash && splash.style.display !== 'none') {
      splash.classList.add('fade-out');
      setTimeout(() => {
        splash.style.display = 'none';
        splash.classList.remove('show');
        showPanel('mainmenu');
      }, 400);
    } else {
      showPanel('mainmenu');
    }
  };

  setTimeout(dismissSplash, 1800);

  document.querySelectorAll('#nav button').forEach(b => {
    b.onclick = () => nav(b.dataset.screen);
  });

  $('menuNewGame')?.addEventListener('click', () => showPanel('onboarding'));

  $('menuLoadGame')?.addEventListener('click', () => {
    const raw = localStorage.getItem('fps_offline_db') || localStorage.getItem('fps_slot1');
    if (!raw) return toast('Brak zapisu');
    try {
      S = JSON.parse(raw);
      if (S.club && S.club.league) {
        currentWorldLeague = LEAGUES_DATA[S.club.league] ? S.club.league : 'Ekstraklasa';
      }
      openGame();
      toast('Wczytano zapis');
    } catch (e) {
      toast('Uszkodzony zapis');
    }
  });

  $('menuSettings')?.addEventListener('click', () => {
    settingsReturnTo = 'mainmenu';
    showPanel('settings');
  });

  $('menuQuit')?.addEventListener('click', () => {
    try {
      if (window.Capacitor?.Plugins?.App?.exitApp) {
        window.Capacitor.Plugins.App.exitApp();
        return;
      }
    } catch (e) {}
    toast('Zamknij aplikację przyciskiem systemowym telefonu');
  });

  $('menuDiscord')?.addEventListener('click', () => {
    if (DISCORD_INVITE_URL) {
      window.open(DISCORD_INVITE_URL, '_blank');
    } else {
      toast('Serwer Discord wkrótce!');
    }
  });

  $('onboardingBack')?.addEventListener('click', () => showPanel('mainmenu'));
  $('settingsBack')?.addEventListener('click', () => showPanel(settingsReturnTo));

  const $anim = $('toggleAnimations');
  if ($anim) {
    $anim.checked = uiSettings.animations;
    $anim.addEventListener('change', () => {
      uiSettings.animations = $anim.checked;
      applySettings();
      saveSettings();
    });
  }

  const $light = $('toggleLightMode');
  if ($light) {
    $light.checked = uiSettings.theme === 'light';
    $light.addEventListener('change', () => {
      uiSettings.theme = $light.checked ? 'light' : 'dark';
      applySettings();
      saveSettings();
    });
  }

  const $sound = $('toggleSound');
  if ($sound) {
    $sound.checked = uiSettings.sound;
    $sound.addEventListener('change', () => {
      uiSettings.sound = $sound.checked;
      saveSettings();
    });
  }

  const $music = $('toggleMusic');
  if ($music) {
    $music.checked = uiSettings.music;
    $music.addEventListener('change', () => {
      uiSettings.music = $music.checked;
      saveSettings();
      if (uiSettings.music) playMusic(currentMusicKey || 'menu'); else stopMusic();
    });
  }

  const $vol = $('volumeSlider');
  if ($vol) {
    $vol.value = Math.round((uiSettings.volume ?? 0.7) * 100);
    $vol.addEventListener('input', () => {
      uiSettings.volume = Number($vol.value) / 100;
      saveSettings();
      applyMusicVolume();
    });
  }

  $('clearSaves')?.addEventListener('click', () => {
    localStorage.removeItem('fps_offline_db');
    localStorage.removeItem('fps_slot1');
    toast('Zapis lokalny usunięty');
  });
});
