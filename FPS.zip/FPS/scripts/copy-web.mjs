import { cp, mkdir, rm } from 'node:fs/promises';

await rm('www', { recursive: true, force: true });
await mkdir('www', { recursive: true });
await cp('frontend', 'www', { recursive: true });
console.log('Frontend copied to www/');
